# Git repo notes

started git repo Nov 22, 2021:
`git clone https://github.com/jayoung/dicty_assemblies.git`

changed git repo so that it does not try to sync file permissions:
`git config core.fileMode false`

to sync the repo:

```
git add --verbose --all .
git commit
git push
```

# Data received from Tera/Mische

## Nov 22 2021

received 5 files via aspera, downloaded to Mac:
```
Assembly Metrics.tsv
MiGS Project Report.docx
Nanopore Reads.zip
110121_322.zip    ## Illumina reads
TL1-KGL29A.zip    ## assembly
```

now upload those from Mac to /fh/fast:
```
cd Downloads/Tera
rsync --verbose  --progress --stats --compress --rsh=/usr/bin/ssh --times *  jayoung@rhino.fhcrc.org:/fh/fast/malik_h/user/jayoung/forOtherPeople/forTera/dicty_assemblies/data/fromMische/2021_Nov22
```

now, on rhino server, remove spaces from file names, and uncompress:
```
mv Assembly\ Metrics.tsv  AssemblyMetrics.tsv 
mv MiGS\ Project\ Report.docx MiGSprojectReport.docx 
mv Nanopore\ Reads.zip  NanoporeReads.zip

unzip 110121_322.zip 
mv 110121_322 illuminaReads_110121_322/
rm 110121_322.zip 

unzip NanoporeReads.zip 
mv Nanopore\ Reads  NanoporeReads
rm NanoporeReads.zip

unzip TL1-KGL29A.zip 
rm TL1-KGL29A.zip 
mv TL1-KGL29A assembly_TL1-KGL29A
mv assembly_TL1-KGL29A/Contig\ Summary.tsv assembly_TL1-KGL29A/ContigSummary.tsv 
```
added to .gitignore:   `*fastq.gz *fq.gz *fastq assembly.fasta`

# Organize files

I think I will keep it all within `data`.

Next level dir will be the strain/species name.

Next level dir will be data type (e.g. `assemblies`/`fastqFiles`)

Next level will be  which version of that data type I'm looking at (e.g. raw, trimmed)

Make links to raw data
```
cd ~/dicty_assemblies/data/KGL29A/fastqFiles
ln -s ../../../fromMische/2021_Nov22/illuminaReads_110121_322/ ./illumina_raw
ln -s ../../../fromMische/2021_Nov22/NanoporeReads/ ./nanopore_raw

cd ../assemblies
ln -s ../../../fromMische/2021_Nov22/AssemblyMetrics.tsv ../../../fromMische/2021_Nov22/assembly_TL1-KGL29A/* .
```

# Tidying files.

On Jan 12 2022, I deleted various large files that I'm not going to use again and could easily regenerate, e.g. rounds 2+ of Klebsiella filtering.  I think I retained all the files needed by 

To clean up a flye assembly dir that I'm not that interested in, while keeping files I use for the results pdf:
```
rm -r ?0-*
rm assembly.fasta assembly_graph.gfa assembly_graph.gv assembly.fasta.fai params.json *first1000bp.fa *first1000bp.fa.megablastnNR
rm -r assembly.fasta_BUSCO/blast_db/ assembly.fasta_BUSCO/logs/ assembly.fasta_BUSCO/run_eukaryota_odb10/
rm -r assembly.fasta_indexFor*
rm -r assembly.fasta_quast/report.html assembly.fasta_quast/genome_stats/ assembly.fasta_quast/icarus_viewers/ assembly.fasta_quast/aligned_stats/ assembly.fasta_quast/basic_stats/ assembly.fasta_quast/contigs_reports/ assembly.fasta_quast/transposed_report.t*
rm -r assembly.fasta_RepeatMasker/assembly.fasta.cat.gz assembly.fasta_RepeatMasker/assembly.fasta.masked assembly.fasta_RepeatMasker/assembly.fasta.out
rm assembly.fasta_RepeatMasker/assembly.fasta.masked_promer/*coords* assembly.fasta_RepeatMasker/assembly.fasta.masked_promer/*delta 
```
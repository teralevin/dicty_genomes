# Flye, sixth attempt, use all reads, without scaffolding

Do the assembly
```
cd ~/dicty_assemblies/data/KGL29A/assemblies/flye_try6_allReads_34mb

ln -s ../../fastqFiles/nanopore_raw/TL1-KGL29A_nanopore.fastq.gz .

# I pretty much go with defaults
# for sbatch, the default is we get 4Gb per CPU (24*4 = 96)
sbatch --cpus-per-task=24 -t 3-0 --job-name=flye6 --wrap="flye --nano-raw TL1-KGL29A_nanopore.fastq.gz --out-dir flye_try6_results --threads 24 --genome-size 34m"
```

It took ~50 mins. 
```
[2022-01-05 12:20:54] INFO: Assembly statistics:

        Total length:   33483710
        Fragments:      123
        Fragments N50:  1284503
        Largest frg:    3428030
        Scaffolds:      0
        Mean coverage:  97
```

xxxx

Index for mapping, GC content, etc, 
```
cd ~/dicty_assemblies/data/KGL29A/assemblies/flye_try6_allReads_34mb/flye_try6_results
../../../../../scripts_perl/GCcontentsimple.bioperl assembly.fasta

# index for BWA
mkdir assembly.fasta_indexForBWA
cd assembly.fasta_indexForBWA/
ln -s ../assembly.fasta .
module load BWA/0.7.17-GCC-10.2.0
bwa index assembly.fasta
module purge
cd ..

# index for IGV
module load IGV/2.8.6-Java-11
igvtools index assembly.fasta
module purge

# index for blast
mkdir assembly.fasta_indexForBlast
cd assembly.fasta_indexForBlast
ln -s ../assembly.fasta .
makeblastdb -in assembly.fasta -dbtype nucl -parse_seqids
cd ..

# index for picard
mkdir assembly.fasta_indexForPicard
cd assembly.fasta_indexForPicard
ln -s ../assembly.fasta .
module load picard/2.25.0-Java-11
java -jar $EBROOTPICARD/picard.jar CreateSequenceDictionary \
      R=assembly.fasta \
      O=assembly.txt.dict
module purge
cp ../assembly.fasta.fai .
cd ..
```




### RepeatMask
28.30 % bases masked
```
cd ~/dicty_assemblies/data/KGL29A/assemblies/flye_try6_allReads_34mb/flye_try6_results
~/dicty_assemblies/scripts_perl/runRepeatMasker.pl -t 24 -species=Dictyostelium assembly.fasta
```

## BUSCO
```
cd ~/dicty_assemblies/data/KGL29A/assemblies/flye_try6_allReads_34mb/flye_try6_results
~/dicty_assemblies/scripts_perl/runBUSCO.pl --lineage=eukaryota_odb10 assembly.fasta
```

### Quast

```
cd ~/dicty_assemblies/data/KGL29A/assemblies/flye_try6_allReads_34mb/flye_try6_results
~/dicty_assemblies/scripts_perl/runQuast.pl --options="-r ~/dicty_assemblies/data/resources/Dictyostelium_discoideum/dicty_chromosomal.names.fa" assembly.fasta
```


### Promer and assemblytics

Try promer on masked seqs
```
cd ~/dicty_assemblies/data/KGL29A/assemblies/flye_try6_allReads_34mb/flye_try6_results/assembly.fasta_RepeatMasker
~/dicty_assemblies/scripts_perl/runPromer.pl assembly.fasta.masked
# assemblytics works with the promer output! I only want the plot, I don't care about the indel reports.
~/dicty_assemblies/scripts_perl/runAssemblytics.pl -anchor=100 assembly.fasta.masked_promer/ref_qry.delta
```


# Flye, second attempt, without scaffolding

After discussion with Ching-Ho I will try it without scaffolding - that might introduce false joins.
```
cd ~/dicty_assemblies/data/KGL29A/assemblies/flye_try2_dont_scaffold
ln -s ../../fastqFiles/nanopore_withoutKlebsiella/TL1-KGL29A_nanopore.nonKleb.fastq.gz .
# I pretty much go with defaults
# for sbatch, the default is we get 4Gb per CPU (24*4 = 96)
sbatch --cpus-per-task=24 -t 3-0 --job-name=flye2 --wrap="flye --nano-raw TL1-KGL29A_nanopore.nonKleb.fastq.gz --out-dir flye_try2_results --threads 24 --genome-size 34m"
```
Took ~30 mins. It's slightly bigger than flye_try1 (31,944,654 bp versus 31,939,432 bp and 132 versus 123 contigs).
```
[2021-12-28 14:13:18] INFO: Assembly statistics:
        Total length:   31944654
        Fragments:      132
        Fragments N50:  4313507
        Largest frg:    4758138
        Scaffolds:      0
        Mean coverage:  49
```

Index for mapping, GC content, etc, 
```
cd ~/dicty_assemblies/data/KGL29A/assemblies/flye_try2_dont_scaffold/flye_try2_results

../../../../../scripts_perl/GCcontentsimple.bioperl assembly.fasta

# index for BWA
mkdir assembly.fasta_indexForBWA
cd assembly.fasta_indexForBWA/
ln -s ../assembly.fasta .
module load BWA/0.7.17-GCC-10.2.0
bwa index assembly.fasta
module purge
cd ..

# index for IGV
module load IGV/2.8.6-Java-11
igvtools index assembly.fasta
module purge

# index for blast
mkdir assembly.fasta_indexForBlast
cd assembly.fasta_indexForBlast
ln -s ../assembly.fasta .
makeblastdb -in assembly.fasta -dbtype nucl -parse_seqids
cd ..

# index for picard
mkdir assembly.fasta_indexForPicard
cd assembly.fasta_indexForPicard
ln -s ../assembly.fasta .
module load picard/2.25.0-Java-11
java -jar $EBROOTPICARD/picard.jar CreateSequenceDictionary \
      R=assembly.fasta \
      O=assembly.txt.dict
module purge
cp ../assembly.fasta.fai .
cd ..
```

### RepeatMask

20.53% bases masked

```
~/dicty_assemblies/scripts_perl/runRepeatMasker.pl -t 24 -species=Dictyostelium assembly.fasta
```



## BUSCO
```
cd ~/dicty_assemblies/data/KGL29A/assemblies/flye_try2_dont_scaffold/flye_try2_results
~/dicty_assemblies/scripts_perl/runBUSCO.pl --lineage=eukaryota_odb10 assembly.fasta
    xxx running 45502004
```


### Quast

```
cd ~/dicty_assemblies/data/KGL29A/assemblies/flye_try2_dont_scaffold/flye_try2_results
~/dicty_assemblies/scripts_perl/runQuast.pl --options="-r ~/dicty_assemblies/data/resources/Dictyostelium_discoideum/dicty_chromosomal.names.fa" assembly.fasta
```


### blast using the Dictyostelium discoideum genome as query

```
cd ~/dicty_assemblies/data/KGL29A/assemblies/flye_try2_dont_scaffold/flye_try2_results
# blastn -query ~/dicty_assemblies/data/resources/Dictyostelium_discoideum/dicty_chromosomal.names.fa -db ./assembly.fasta_indexForBlast/assembly.fasta -task blastn -out dicty_chromosomal.names.fa.blastn_assembly -num_threads 4
      #  this ran for 20hrs without finishing! don't do it like this. maybe megablast would be OK. Maybe it'd be OK with RepeatMasked genomes     
```


### blast using the one Klebsiella genome I downloaded as query, to ask why my subtraction was incomplete.

It looks like the contigs that DO match that Klebsiella reference only do so with ~85% identity, although in my blastnNR results they have 100% matches
```
cd ~/dicty_assemblies/data/KGL29A/assemblies/flye_try2_dont_scaffold/flye_try2_results
blastn -query ~/dicty_assemblies/data/resources/klebsiella/CP052309acc.txt.fasta -db ./assembly.fasta_indexForBlast/assembly.fasta -task blastn -out CP052309acc.txt.fasta.blastn_assembly
```


### compare to Dictostelium discoideum ref

Nucmer with the settings I used before is not useful - I think the genomes are too divergent.
```
cd ~/dicty_assemblies/data/KGL29A/assemblies/flye_try2_dont_scaffold/flye_try2_results
~/dicty_assemblies/scripts_perl/runNucmer.pl -sbatch=1 -t 12 assembly.fasta
~/dicty_assemblies/scripts_perl/runAssemblytics.pl assembly.fasta_MUMMER/ref_qry.delta
```


Try promer on masked seqs
```
cd ~/dicty_assemblies/data/KGL29A/assemblies/flye_try2_dont_scaffold/flye_try2_results/assembly.fasta_RepeatMasker

~/dicty_assemblies/scripts_perl/runPromer.pl -sbatch=1 assembly.fasta.masked 
# assemblytics works with the promer output! I only want the plot, I don't care about the indel reports.
~/dicty_assemblies/scripts_perl/runAssemblytics.pl -anchor=100 assembly.fasta.masked_promer/ref_qry.delta
    xxxx running 45404879
```


### blast first 1kb of each contig to NCBI

I want to see if there are more contaminants I should be screening out
```
cd ~/dicty_assemblies/data/KGL29A/assemblies/flye_try2_dont_scaffold/flye_try2_results
../../../../../scripts_perl/getFirstBitOfEachSeq.bioperl assembly.fasta

blastn -remote -db nr -task megablast -query assembly.first1000bp.fa -out assembly.first1000bp.fa.megablastnNR -num_descriptions 5 -num_alignments 5
    # ran - took quite a while, and got some errors
```

I can already see that there are more Klebsiella contigs, some E. coli contigs, some dicty contigs. There's also a 100% match to Kluyveromyces lactis mitochondrial seqs and Galactomyces candidum mitochondrial seq

To collect more bacterial reference sequences to use to subtract reads:
- parse NR blast (and perhaps make a table for R to read in, assigning each contig to a species)
- require 100% match
- ignore dicty hits
- for each HIT seq, count how many QUERY contigs hit it
- sort by most-often matched seqs
- take first HIT seq, go through contigs again, 

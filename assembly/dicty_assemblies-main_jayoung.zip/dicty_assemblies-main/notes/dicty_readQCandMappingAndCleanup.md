# Read QC

## Read counts:
```
cd ~/dicty_assemblies/KGL29A/data/fastqFiles
../../../scripts_perl/countFastqReads.pl *raw/*gz
mv readcounts.txt readcounts.raw.txt

../../../scripts_perl/countFastqBases.pl *raw/*gz
mv basepaircounts.txt basepaircounts.raw.txt
```
11.1 million paired-end Illumina reads
3.4 million Nanopore reads 
(total 25 million)

## Fastqc
```
cd ~/dicty_assemblies/KGL29A/data/fastqFiles/illumina_raw
../../../../scripts_perl/runFastqcOnEachFileOrPairIndividually.pl *gz
cd ../nanopore_raw
../../../../scripts_perl/runFastqcOnEachFileOrPairIndividually.pl --options="--nano" *gz
```
Illumina:  read lengths are 35-151 (both ends) so I think these have already been trimmed at least a bit

Nanopore: read lengths are 21-142251

Both Illumina and Nanopore libraries show a big Klebsiella contaminant peak (high GC content)

Convert nanopore to fasta so I can run some scripts. Found a trick here: https://bioinformaticsworkbook.org/dataWrangling/fastaq-manipulations/converting-fastq-format-to-fasta.html#gsc.tab=0

```
zcat TL1-KGL29A_nanopore.fastq.gz | sed -n '1~4s/^@/>/p;2~4p' > TL1-KGL29A_nanopore.fasta
../../../../scripts_perl/GCcontentsimple.bioperl TL1-KGL29A_nanopore.fasta
rm TL1-KGL29A_nanopore.fasta
```


# Map reads to MIGS initial assembly, to understand it better

e.g. I will want to look at coverage versus GC

For the Illumina reads, I use bwa-mem
```
cd ~/dicty_assemblies/data/KGL29A/fastqFiles/illumina_raw/map_to_initialMIGSassembly_bwa
../../../../../scripts_perl/run_bwa_mem_paired_initialMIGS.pl ../TL1_KGL29A_S322_R1_001.fastq.gz
```

For the Nanopore reads, I use minimap2
```
cd ~/dicty_assemblies/data/KGL29A/fastqFiles/nanopore_raw/map_to_initialMIGSassembly_minimap2
../../../../../scripts_perl/run_minimap2_initialMIGS.pl ../TL1-KGL29A_nanopore.fastq.gz
```

93.3% Nanopore reads map to the initial assembly
88.8% Nanopore reads map to the initial assembly

Get mean coverage for each contig using samtools
```
module load SAMtools/1.11-GCC-10.2.0
cd ~/dicty_assemblies/data/KGL29A/fastqFiles/illumina_raw/map_to_initialMIGSassembly_bwa
samtools coverage TL1_KGL29A_S322_R1_001.bwa.bam > TL1_KGL29A_S322_R1_001.bwa.coverage.txt

cd ../../nanopore_raw/map_to_initialMIGSassembly_minimap2
samtools coverage TL1-KGL29A_nanopore.minimap2.bam > TL1-KGL29A_nanopore.minimap2.coverage.txt
module purge
```

# Map reads to Klebsiella, so I can subtract out contaminating reads:

For the Illumina reads, I use bwa-mem. 
```
cd ~/dicty_assemblies/data/KGL29A/fastqFiles/illumina_raw/map_to_klebsiella_bwa
../../../../../scripts_perl/run_bwa_mem_paired_klebsiella.pl ../TL1_KGL29A_S322_R1_001.fastq.gz
```

For the Nanopore reads, I use [minimap2](https://github.com/lh3/minimap2) (as advised by Ching-Ho). Default settings are suitable for nanopore reads. I won't try to get cigar strings for these alignments.   
```
cd ~/dicty_assemblies/data/KGL29A/fastqFiles/nanopore_raw/map_to_klebsiella_minimap2
../../../../../scripts_perl/run_minimap2_klebsiella.pl ../TL1-KGL29A_nanopore.fastq.gz
```

Get mean coverage for each contig using samtools
```
module load SAMtools/1.11-GCC-10.2.0
cd ~/dicty_assemblies/data/KGL29A/fastqFiles/illumina_raw/map_to_klebsiella_bwa/
samtools coverage TL1_KGL29A_S322_R1_001.bwa.bam > TL1_KGL29A_S322_R1_001.bwa.coverage.txt

cd ../../nanopore_raw/map_to_klebsiella_minimap2
samtools coverage TL1-KGL29A_nanopore.minimap2.bam > TL1-KGL29A_nanopore.minimap2.coverage.txt
module purge
```

59.6% Illumina reads map to Klebsiella.
52.3% Nanopore reads map to Klebsiella.

Get unmapped reads from these bams and make links to the fastq files with more sensible names

```
# Illumina
cd ~/dicty_assemblies/data/KGL29A/fastqFiles/illumina_raw/map_to_klebsiella_bwa
../../../../../scripts_perl/getUnmappedReadsFromBamFile.pl --pair=1 TL1_KGL29A_S322_R1_001.bwa.bam
cd ../../illumina_withoutKlebsiella
ln -s ../illumina_raw/map_to_klebsiella_bwa/TL1_KGL29A_S322_R1_001.bwa.unmapped_R1.fastq.gz ./TL1_KGL29A_S322_R1.nonKleb.fastq.gz
ln -s ../illumina_raw/map_to_klebsiella_bwa/TL1_KGL29A_S322_R1_001.bwa.unmapped_R2.fastq.gz ./TL1_KGL29A_S322_R2.nonKleb.fastq.gz
ln -s ../illumina_raw/map_to_klebsiella_bwa/TL1_KGL29A_S322_R1_001.bwa.unmapped_singletons.fastq.gz ./TL1_KGL29A_S322_singletons.nonKleb.fastq.gz

# Nanopore
cd ../../nanopore_raw/map_to_klebsiella_minimap2
../../../../../scripts_perl/getUnmappedReadsFromBamFile.pl --pair=0 TL1-KGL29A_nanopore.minimap2.bam
cd ../../nanopore_withoutKlebsiella
ln -s ../nanopore_raw/map_to_klebsiella_minimap2/TL1-KGL29A_nanopore.minimap2.unmapped.fastq.gz ./TL1-KGL29A_nanopore.nonKleb.fastq.gz
```

## QC on non-Klebsiella reads

```
# read counts
cd ~/dicty_assemblies/data/KGL29A/fastqFiles
../../../scripts_perl/countFastqReads.pl *_withoutKlebsiella/*gz
mv readcounts.txt readcounts.nonKlebsiella.txt

# basepair counts
../../../scripts_perl/countFastqBases.pl *withoutKlebsiella/*gz
mv basepaircounts.txt basepaircounts.nonKlebsiella.txt

# fastqc
cd illumina_withoutKlebsiella
../../../../scripts_perl/runFastqcOnEachFileOrPairIndividually.pl *gz
cd ../nanopore_withoutKlebsiella
../../../../scripts_perl/runFastqcOnEachFileOrPairIndividually.pl --options="--nano" *gz

# read lengths (just nanopore)
cd ~/dicty_assemblies/data/KGL29A/fastqFiles/nanopore_raw
../../../../scripts_perl/seqlengthFastq.pl TL1-KGL29A_nanopore.fastq.gz
cd ../nanopore_withoutKlebsiella
../../../../scripts_perl/seqlengthFastq.pl TL1-KGL29A_nanopore.nonKleb.fastq.gz 
```

# More read filtering, starting with the non-Klebsiella reads

## Illumina reads - get only pairs where both ends are >= 140bp in length

Note: for anything R on the cluster, I want to be working on a J or K-class node (https://github.com/FredHutch/easybuild-life-sciences/issues/515).  Here's the command to make that happen: `grabnode --constraint=gizmok`
```
cd ~/HSV1_Mx_evolution/data/trimmedReads_newNames_trimMore_withoutMycoplasma
module load fhR/4.0.2-foss-2019b
# paired ends:
Rscript ../../../../scripts_R/filterFastqByReadLength.R --min=140 --pair=1 TL1_KGL29A_S322_R1.nonKleb.fastq.gz
module purge
mkdir ../illumina_withoutKlebsiella_min140
mv *min140.fq.gz ../illumina_withoutKlebsiella_min140/
cd ..

../../../scripts_perl/countFastqReads.pl illumina_withoutKlebsiella_min140/*gz
mv readcounts.txt readcounts.nonKlebsiella.min140.txt

../../../scripts_perl/countFastqBases.pl illumina_withoutKlebsiella_min140/*gz
mv basepaircounts.txt basepaircounts.nonKlebsiella.min140.txt

cd illumina_withoutKlebsiella_min140
../../../../scripts_perl/runFastqcOnEachFileOrPairIndividually.pl *gz
```

# Map reads to a larger database of contaminants, so I can subtract out contaminating reads:

xxxxx actually, I wonder if bwa-mem is being too generous? it is finding a bunch of things that do have a match, but have a large soft-masked region
xxxx think about the same question for minimap2

For the Illumina reads, I use bwa-mem. 
```
cd ~/dicty_assemblies/data/KGL29A/fastqFiles/illumina_withoutKlebsiella_min140/map_to_combinedContaminantsV1_bwa
../../../../../scripts_perl/run_bwa_mem_paired_combinedContaminantsV1.pl ../TL1_KGL29A_S322_R1.nonKleb.min140.fq.gz
```

Nanopore reads   
```
cd ~/dicty_assemblies/data/KGL29A/fastqFiles/nanopore_withoutKlebsiella/map_to_combinedContaminantsV1_minimap2/
../../../../../scripts_perl/run_minimap2_combinedContaminantsV1.pl ../TL1-KGL29A_nanopore.nonKleb.fastq.gz
```

Another 17% of reads now matched contaminants

Count reads on each target: very few match the Klebsiella genome I originally mapped to (not surprising) but quite a few match the other contaminant genomes.

```
module load SAMtools
cd ~/dicty_assemblies/data/KGL29A/fastqFiles/nanopore_withoutKlebsiella/map_to_combinedContaminantsV1_minimap2
~/dicty_assemblies/scripts_perl/getReadCountsPerChrSamtools.pl TL1-KGL29A_nanopore.nonKleb.minimap2.bam  
cd ../../illumina_withoutKlebsiella_min140/map_to_combinedContaminantsV1_bwa/
~/dicty_assemblies/scripts_perl/getReadCountsPerChrSamtools.pl TL1_KGL29A_S322_R1.nonKleb.min140.bwa.bam 
module purge
```

Get unmapped reads from these bams and make links to the fastq files with more sensible names:
```
# Illumina
cd ~/dicty_assemblies/data/KGL29A/fastqFiles/illumina_withoutKlebsiella_min140/map_to_combinedContaminantsV1_bwa
../../../../../scripts_perl/getUnmappedReadsFromBamFile.pl --pair=1 TL1_KGL29A_S322_R1.nonKleb.min140.bwa.bam
cd ../../illumina_withoutKlebsiella_min140_round2
ln -s ../illumina_withoutKlebsiella_min140/map_to_combinedContaminantsV1_bwa/TL1_KGL29A_S322_R1.nonKleb.min140.bwa.unmapped_R1.fastq.gz ./TL1_KGL29A_S322_R1.nonKleb2.fastq.gz
ln -s ../illumina_withoutKlebsiella_min140/map_to_combinedContaminantsV1_bwa/TL1_KGL29A_S322_R1.nonKleb.min140.bwa.unmapped_R2.fastq.gz ./TL1_KGL29A_S322_R2.nonKleb2.fastq.gz
ln -s ../illumina_withoutKlebsiella_min140/map_to_combinedContaminantsV1_bwa/TL1_KGL29A_S322_R1.nonKleb.min140.bwa.unmapped_singletons.fastq.gz ./TL1_KGL29A_S322_singletons.nonKleb2.fastq.gz

# Nanopore
cd ../../nanopore_withoutKlebsiella/map_to_combinedContaminantsV1_minimap2
../../../../../scripts_perl/getUnmappedReadsFromBamFile.pl --pair=0  TL1-KGL29A_nanopore.nonKleb.minimap2.bam
cd ../../nanopore_withoutKlebsiella_round2
ln -s ../nanopore_withoutKlebsiella/map_to_combinedContaminantsV1_minimap2/TL1-KGL29A_nanopore.nonKleb.minimap2.unmapped.fastq.gz ./TL1-KGL29A_nanopore.nonKlebV2.fastq.gz
```

## QC on non-Klebsiella reads round 2

Fastqc shows me the GC content profile looks like I really have got rid of most contaminant reads now.

```
# read counts
cd ~/dicty_assemblies/data/KGL29A/fastqFiles
../../../scripts_perl/countFastqReads.pl *round2/*gz
mv readcounts.txt readcounts.nonKlebsiella_round2.txt

# basepair counts
../../../scripts_perl/countFastqBases.pl *round2/*gz
mv basepaircounts.txt basepaircounts.nonKlebsiella_round2.txt

# fastqc
cd illumina_withoutKlebsiella_min140_round2
../../../../scripts_perl/runFastqcOnEachFileOrPairIndividually.pl *gz
cd ../nanopore_withoutKlebsiella_round2
../../../../scripts_perl/runFastqcOnEachFileOrPairIndividually.pl --options="--nano" *gz

# read lengths (just nanopore)
cd ~/dicty_assemblies/data/KGL29A/fastqFiles/nanopore_withoutKlebsiella_round2
../../../../scripts_perl/seqlengthFastq.pl TL1-KGL29A_nanopore.nonKlebV2.fastq.gz
```


# Map reads to v2 of the larger database of contaminants, so I can subtract out contaminating reads:

Deleted these!

For the Illumina reads, I use bwa-mem (did not use sbatch - queue!)  
```
cd ~/dicty_assemblies/data/KGL29A/fastqFiles/illumina_withoutKlebsiella_min140_round2/map_to_combinedContaminantsV2_bwa
../../../../../scripts_perl/run_bwa_mem_paired_combinedContaminantsV2.pl --sbatch=0 ../TL1_KGL29A_S322_R1.nonKleb2.fastq.gz
module load SAMtools
~/dicty_assemblies/scripts_perl/getReadCountsPerChrSamtools.pl TL1_KGL29A_S322_R1.nonKleb2.bwa.bam
module purge
../../../../../scripts_perl/getUnmappedReadsFromBamFile.pl --sbatch=0 --pair=1 TL1_KGL29A_S322_R1.nonKleb2.bwa.bam
cd ../../illumina_withoutKlebsiella_min140_round3
ln -s ../illumina_withoutKlebsiella_min140_round2/map_to_combinedContaminantsV2_bwa/TL1_KGL29A_S322_R1.nonKleb2.bwa.unmapped_R1.fastq.gz ./TL1_KGL29A_S322_R1.nonKleb3.fastq.gz
ln -s ../illumina_withoutKlebsiella_min140_round2/map_to_combinedContaminantsV2_bwa/TL1_KGL29A_S322_R1.nonKleb2.bwa.unmapped_R2.fastq.gz ./TL1_KGL29A_S322_R2.nonKleb3.fastq.gz
ln -s ../illumina_withoutKlebsiella_min140_round2/map_to_combinedContaminantsV2_bwa/TL1_KGL29A_S322_R1.nonKleb2.bwa.unmapped_singletons.fastq.gz ./TL1_KGL29A_S322_singletons.nonKleb3.fastq.gz
```

Nanopore reads (did not use sbatch - queue!)  
```
cd ~/dicty_assemblies/data/KGL29A/fastqFiles/nanopore_withoutKlebsiella_round2/map_to_combinedContaminantsV2_minimap2/
../../../../../scripts_perl/run_minimap2_combinedContaminantsV2.pl -sbatch=0 ../TL1-KGL29A_nanopore.nonKlebV2.fastq.gz
module load SAMtools
~/dicty_assemblies/scripts_perl/getReadCountsPerChrSamtools.pl TL1-KGL29A_nanopore.nonKlebV2.minimap2.bam  
module purge
# get unmapped reads and make links

../../../../../scripts_perl/getUnmappedReadsFromBamFile.pl --sbatch=0 --pair=0 TL1-KGL29A_nanopore.nonKlebV2.minimap2.bam
cd ../../nanopore_withoutKlebsiella_round3
ln -s ../nanopore_withoutKlebsiella_round2/map_to_combinedContaminantsV2_minimap2/TL1-KGL29A_nanopore.nonKlebV2.minimap2.unmapped.fastq.gz ./TL1-KGL29A_nanopore.nonKlebV3.fastq.gz

```
Another 4% of reads now matched contaminants

## QC on non-Klebsiella reads round 3

Fastqc shows me the GC content profile looks like I really have got rid of most contaminant reads now.

```
# read counts
cd ~/dicty_assemblies/data/KGL29A/fastqFiles
../../../scripts_perl/countFastqReads.pl *round3/*gz
mv readcounts.txt readcounts.nonKlebsiella_round3.txt

# basepair counts
../../../scripts_perl/countFastqBases.pl *round3/*gz
mv basepaircounts.txt basepaircounts.nonKlebsiella_round3.txt

# fastqc
module load FastQC/0.11.9-Java-11
cd illumina_withoutKlebsiella_min140_round3
../../../../scripts_perl/runFastqcOnEachFileOrPairIndividually.pl --sbatch=0 *gz
cd ../nanopore_withoutKlebsiella_round3
../../../../scripts_perl/runFastqcOnEachFileOrPairIndividually.pl --options="--nano" *gz
module purge

# read lengths (just nanopore)
cd ~/dicty_assemblies/data/KGL29A/fastqFiles/nanopore_withoutKlebsiella_round3
../../../../scripts_perl/seqlengthFastq.pl TL1-KGL29A_nanopore.nonKlebV3.fastq.gz
```

# fourth round of Klebsiella filtering


xxx



# Map reads to v3 of the larger database of contaminants, so I can subtract out contaminating reads:

For the Illumina reads, I use bwa-mem 
```
cd ~/dicty_assemblies/data/KGL29A/fastqFiles/illumina_withoutKlebsiella_min140_round3/map_to_combinedContaminantsV3_bwa
../../../../../scripts_perl/run_bwa_mem_paired_combinedContaminantsV3.pl ../TL1_KGL29A_S322_R1.nonKleb3.fastq.gz
module load SAMtools
~/dicty_assemblies/scripts_perl/getReadCountsPerChrSamtools.pl TL1_KGL29A_S322_R1.nonKleb3.bwa.bam
module purge
../../../../../scripts_perl/getUnmappedReadsFromBamFile.pl --pair=1 TL1_KGL29A_S322_R1.nonKleb3.bwa.bam

mkdir ../../illumina_withoutKlebsiella_min140_round4
cd ../../illumina_withoutKlebsiella_min140_round4
ln -s ../illumina_withoutKlebsiella_min140_round3/map_to_combinedContaminantsV3_bwa/TL1_KGL29A_S322_R1.nonKleb3.bwa.unmapped_R1.fastq.gz ./TL1_KGL29A_S322_R1.nonKleb4.fastq.gz
ln -s ../illumina_withoutKlebsiella_min140_round3/map_to_combinedContaminantsV3_bwa/TL1_KGL29A_S322_R1.nonKleb3.bwa.unmapped_R2.fastq.gz ./TL1_KGL29A_S322_R2.nonKleb4.fastq.gz
ln -s ../illumina_withoutKlebsiella_min140_round3/map_to_combinedContaminantsV3_bwa/TL1_KGL29A_S322_R1.nonKleb3.bwa.unmapped_singletons.fastq.gz ./TL1_KGL29A_S322_singletons.nonKleb4.fastq.gz

```

Nanopore reads 
```
cd ~/dicty_assemblies/data/KGL29A/fastqFiles/nanopore_withoutKlebsiella_round3/map_to_combinedContaminantsV3_minimap2/
../../../../../scripts_perl/run_minimap2_combinedContaminantsV3.pl ../TL1-KGL29A_nanopore.nonKlebV3.fastq.gz
module load SAMtools
~/dicty_assemblies/scripts_perl/getReadCountsPerChrSamtools.pl TL1-KGL29A_nanopore.nonKlebV3.minimap2.bam  
module purge
# get unmapped reads and make links

../../../../../scripts_perl/getUnmappedReadsFromBamFile.pl --pair=0 TL1-KGL29A_nanopore.nonKlebV3.minimap2.bam
mkdir ../../nanopore_withoutKlebsiella_round4
cd ../../nanopore_withoutKlebsiella_round4
ln -s ../nanopore_withoutKlebsiella_round3/map_to_combinedContaminantsV3_minimap2/TL1-KGL29A_nanopore.nonKlebV3.minimap2.unmapped.fastq.gz ./TL1-KGL29A_nanopore.nonKlebV4.fastq.gz
```
<1% of reads matched contaminants this time around

## QC on non-Klebsiella reads round 4

```
# read counts
cd ~/dicty_assemblies/data/KGL29A/fastqFiles
../../../scripts_perl/countFastqReads.pl *round4/*gz
mv readcounts.txt readcounts.nonKlebsiella_round4.txt

# basepair counts
../../../scripts_perl/countFastqBases.pl *round4/*gz
mv basepaircounts.txt basepaircounts.nonKlebsiella_round4.txt

# fastqc
cd illumina_withoutKlebsiella_min140_round4
../../../../scripts_perl/runFastqcOnEachFileOrPairIndividually.pl *gz
cd ../nanopore_withoutKlebsiella_round4
../../../../scripts_perl/runFastqcOnEachFileOrPairIndividually.pl --options="--nano" *gz

# read lengths (just nanopore)
cd ~/dicty_assemblies/data/KGL29A/fastqFiles/nanopore_withoutKlebsiella_round4
../../../../scripts_perl/seqlengthFastq.pl TL1-KGL29A_nanopore.nonKlebV4.fastq.gz
```
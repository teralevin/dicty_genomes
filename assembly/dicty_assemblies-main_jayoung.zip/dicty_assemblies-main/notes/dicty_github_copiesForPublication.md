# Goal

want relevant scripts copied into Tera's public github (https://github.com/teralevin/dicty_genomes). I have a copy of that in `/home/jayoung/FH_fast_storage/forOtherPeople/forTera/dicty/github_tera`

My scripts will go in `/home/jayoung/FH_fast_storage/forOtherPeople/forTera/dicty/github_tera/dicty_genomes/assembly/`



## Edit scripts

Should have a header like this:
```
####### runQuast.pl fastafile(s)
### runs a command like this:     quast.py --threads 4 -o cerSim1.fa_quast cerSim1.fa
### by generating a shell script and using sbatch to run it on a cluster

### set defaults
```

## Scripts to copy

01a_runFastqc.pl
```
cd ~/dicty_assemblies/scripts_perl
cp runFastqcOnEachFileOrPairIndividually.pl ../../../github_tera/dicty_genomes/assembly/01a_runFastqc.pl
```


02 - flye - there is no script

03_getFirst2kbOfEachSeq.pl
```
cd ~/dicty_assemblies/scripts_perl
cp getFirstBitOfEachSeq.bioperl ../../../github_tera/dicty_genomes/assembly/03_getFirst2kbOfEachSeq.pl
```

04a minimap
```
cd ~/dicty_assemblies/scripts_perl
cp run_minimap2_klebsiella.pl ../../../github_tera/dicty_genomes/assembly/04a_runMinimap2.pl
```

04b bwa
```
cd ~/dicty_assemblies/scripts_perl

cp run_bwa_mem_paired_klebsiella.pl ../../../github_tera/dicty_genomes/assembly/04b_runBWA.pl
```

04c_getUnmappedReadsBam.pl
```
cd ~/dicty_assemblies/scripts_perl
cp getUnmappedReadsFromBamFile.pl ../../../github_tera/dicty_genomes/assembly/04c_getUnmappedReadsBam.pl
```

05 - runBUSCO.pl
```
cd ~/dicty_assemblies/scripts_perl
cp runBUSCO.pl ../../../github_tera/dicty_genomes/assembly/05_runBUSCO.pl
```

06 - runPilon.sh
```
cd ~/dicty_assemblies/scripts_shell
cp runPilon.sh ../../../github_tera/dicty_genomes/assembly/06_runPilon.sh
```

07 - runKAD.pl
```
cd ~/dicty_assemblies/scripts_perl
cp runKAD.pl ../../../github_tera/dicty_genomes/assembly/07_runKAD.pl
```

08 - runQuast.pl
```
cd ~/dicty_assemblies/scripts_perl
cp runQuast.pl ../../../github_tera/dicty_genomes/assembly/08_runQuast.pl
```



## Syncing to Tera's github

On Aug 6 I copied in a bunch of my scripts into that repo and intend to do a pull request.

I did `git add` and `git commit`.   I cannot do `git push` because I don't have permission.  I do this to undo the commit:
```
git reset --soft HEAD~1
```
I don't think I undid the `add`

Instead I will try creating a new branch and doing a pull request:

```
cd /fh/fast/malik_h/user/jayoung/forOtherPeople/forTera/dicty/github_tera/dicty_genomes

# list existing branches
git branch

# make new branch
git branch janet_branch

# check branch creation worked
git branch

# copy the files I'll want to put in the new branch somwwhere:
cp assembly/* ../for_teralevin_github/
cp README.md ../for_teralevin_github/

# switch to janet_branch
git checkout janet_branch

# now try add commit push
git add --all .
git commit -m "janet add assembly scripts"
    On branch janet_branch
    nothing to commit, working tree clean

# can't do that either - don't have push permission
git push --set-upstream origin janet_branch

# instead I will compress for_teralevin_github and email it
tar czf for_teralevin_github.tar.gz for_teralevin_github
```



# Flye, first attempt. 

```
cd ~/dicty_assemblies/data/KGL29A/assemblies/flye_try1_scaffold
# make links to sequence data
ln -s ../../fastqFiles/nanopore_withoutKlebsiella/TL1-KGL29A_nanopore.nonKleb.fastq.gz .
# I pretty much go with defaults except I add scaffolds
# for sbatch, the default is we get 4Gb per CPU (24*4 = 96)
sbatch --cpus-per-task=24 -t 3-0 --job-name=flye1 --wrap="flye --nano-raw TL1-KGL29A_nanopore.nonKleb.fastq.gz --out-dir flye_try1_results --threads 24 --genome-size 34m --scaffold"
```

It worked, took ~30 mins, gave me an assembly with 123 contigs. This is the tail end of the stdout:
```
[2021-12-28 12:57:54] root: INFO: Assembly statistics:
        Total length:   31939432
        Fragments:      123
        Fragments N50:  4665785
        Largest frg:    5170217
        Scaffolds:      3
        Mean coverage:  49
```
This seems promising. The assembly is in `assembly.fasta`, and contains 120 'contigs' and 3 'scaffolds'.  `assembly_info.txt` can show how the scaffolds were put together and has the coverage for each contig


# Index for mapping, GC content, etc, 
```
cd ~/dicty_assemblies/data/KGL29A/assemblies/flye_try1_scaffold/flye_try1_results

../../../../../scripts_perl/GCcontentsimple.bioperl assembly.fasta

# index for BWA
mkdir assembly.fasta_indexForBWA
cd assembly.fasta_indexForBWA/
ln -s ../assembly.fasta .
module load BWA/0.7.17-GCC-10.2.0
bwa index assembly.fasta
module purge
cd ..

# index for IGV
module load IGV/2.8.6-Java-11
igvtools index assembly.fasta
module purge

# index for blast
mkdir assembly.fasta_indexForBlast
cd assembly.fasta_indexForBlast
ln -s ../assembly.fasta .
makeblastdb -in assembly.fasta -dbtype nucl -parse_seqids
cd ..

# index for picard
mkdir assembly.fasta_indexForPicard
cd assembly.fasta_indexForPicard
ln -s ../assembly.fasta .
module load picard/2.25.0-Java-11
java -jar $EBROOTPICARD/picard.jar CreateSequenceDictionary \
      R=assembly.fasta \
      O=assembly.txt.dict
module purge
cp ../assembly.fasta.fai .
cd ..
```

# BUSCO
```
cd ~/dicty_assemblies/data/KGL29A/assemblies/flye_try1_scaffold/flye_try1_results
~/dicty_assemblies/scripts_perl/runBUSCO.pl -t 16 --lineage=eukaryota_odb10 assembly.fasta
```

# Quast
```
cd ~/dicty_assemblies/data/KGL29A/assemblies/flye_try1_scaffold/flye_try1_results
~/dicty_assemblies/scripts_perl/runQuast.pl --options="-r ~/dicty_assemblies/data/resources/Dictyostelium_discoideum/dicty_chromosomal.names.fa" assembly.fasta
```

# RepeatMask
20.5 % bases masked
```
cd ~/dicty_assemblies/data/KGL29A/assemblies/flye_try1_scaffold/flye_try1_results
~/dicty_assemblies/scripts_perl/runRepeatMasker.pl -t 24 -species=Dictyostelium assembly.fasta
```



## Blast first 1kb of each contig to NCBI

I want to see if there are more contaminants I should be screening out
```
cd ~/dicty_assemblies/data/KGL29A/assemblies/flye_try1_scaffold/flye_try1_results
../../../../../scripts_perl/getFirstBitOfEachSeq.bioperl assembly.fasta

blastn -remote -db nr -task megablast -query assembly.first1000bp.fa -out assembly.first1000bp.fa.megablastnNR -num_descriptions 5 -num_alignments 5
    # actually finished surprisingly fast
# parse, keeping hits with e<10-5
~/dicty_assemblies/scripts_perl/blastparsenew.bioperl -interactive=0 assembly.first1000bp.fa.megablastnNR

```

# Promer and assemblytics
Try promer on masked seqs
```
cd ~/dicty_assemblies/data/KGL29A/assemblies/flye_try1_scaffold/flye_try1_results/assembly.fasta_RepeatMasker
~/dicty_assemblies/scripts_perl/runPromer.pl -sbatch=1 assembly.fasta.masked
~/dicty_assemblies/scripts_perl/runAssemblytics.pl -anchor=100 assembly.fasta.masked_promer/ref_qry.delta
```

# polishing with PILON - try 10 rounds, using bwa as mapper

use a looping approach: see https://bioinformaticsworkbook.org/dataAnalysis/GenomeAssembly/Iterate_Pilon_Genome_Polishing.html#gsc.tab=0

```
cd ~/dicty_assemblies/data/KGL29A/assemblies/flye_try1_scaffold/flye_try1_results/assembly.fasta_PILONpolishing_10rounds

# link assembly and Illumina reads. I'll give the original assembly a new name, assembly01.fasta, so that it will be OK in the script
ln -s ../assembly.fasta ./assembly01.fasta
ln -s ../../../../fastqFiles/illumina_withoutKlebsiella_min140/TL1_KGL29A_S322_R1.nonKleb.min140.fq.gz .
ln -s ../../../../fastqFiles/illumina_withoutKlebsiella_min140/TL1_KGL29A_S322_R2.nonKleb.min140.fq.gz .

# make a shell script that does 10 rounds of polishing - I'll ask for 20 threads:
for f in {01..10}; do echo "bash ~/dicty_assemblies/scripts_shell/runPilon.sh /fh/fast/malik_h/user/jayoung/forOtherPeople/forTera/dicty_assemblies/data/KGL29A/assemblies/flye_try1_scaffold/flye_try1_results/assembly.fasta_PILONpolishing_10rounds assembly"${f}".fasta TL1_KGL29A_S322_R1.nonKleb.min140.fq.gz TL1_KGL29A_S322_R2.nonKleb.min140.fq.gz 20; mv assembly"${f}".pilon.fasta" ;done |paste - <(for f in {02..11}; do echo $line" assembly"${f}".fasta";done) |sed 's/\t/ /g' > PolishLoop.sh

# now run that shell script:
module purge
sbatch --job-name=pilon10x --cpus-per-task=20 --wrap="bash ./PolishLoop.sh"
    ran: 45563567
mv slurm-45563567.out  pilon_polishing.log.txt

# tidy up: remove the bam files and bwa index files, run KAD error detection and BUSCO on each iteration, uncomment the removal of sam and bam from the runPilon.sh script
rm *bam *bai *.amb *.ann *.bwt *.pac *.sa
```



## BUSCO on all 10 polished assemblies
```
cd ~/dicty_assemblies/data/KGL29A/assemblies/flye_try1_scaffold/flye_try1_results/assembly.fasta_PILONpolishing_10rounds
~/dicty_assemblies/scripts_perl/runBUSCO.pl -t 4 --lineage=eukaryota_odb10 assembly*.fasta

# remove all files except final report:
rm -r *BUSCO/blast_db *BUSCO/logs *BUSCO/run_eukaryota_odb10
```

## KAD error rate estimation:
```
cd ~/dicty_assemblies/data/KGL29A/assemblies/flye_try1_scaffold/flye_try1_results/assembly.fasta_PILONpolishing_10rounds
~/dicty_assemblies/scripts_perl/runKAD.pl --t=20 --reads=TL1_KGL29A_S322_R1.nonKleb.min140.fq.gz,TL1_KGL29A_S322_R2.nonKleb.min140.fq.gz assembly*fasta
```


## tblastn these assemblies with 2296 high quality intronless Dicty proteins


Get only the top hit
```
cd ~/dicty_assemblies/data/KGL29A/assemblies/flye_try1_scaffold/flye_try1_results

tblastn -query ~/dicty_assemblies/data/resources/Dictyostelium_discoideum/annotations_2022_Jan4/dicty_primary_protein.filteredIntronlessPeps.fa -db assembly.fasta_indexForBlast/assembly.fasta -num_threads 4 -num_descriptions 5 -num_alignments 5 -out dicty_intronlessPeps.tblastn_assembly

cd assembly.fasta_PILONpolishing_10rounds
# I have to fix the contig names in the polished assemblies, otherwise makeblastdb won't format the later iterations:
~/dicty_assemblies/scripts_perl/fixPILONseqnames.bioperl assembly*fasta

~/dicty_assemblies/scripts_perl/runBlast_dictyQueryPeps.pl assembly*names.fa
~/dicty_assemblies/scripts_perl/blastparsenew.bioperl -interactive=0 *tblastn*names

head -2000 dicty_intronlessPeps.tblastn_assembly01.names > test.tblastn_assembly01.names
   # then edited to remove the last incomplete query result
~/dicty_assemblies/scripts_perl/blastparsenew.bioperl -interactive=0 test.tblastn_assembly01.names

# remove blast index files:
rm assembly??.names.fa.n??
```

# Copy my favorite assembly to a more central place
I know it's called assembly05.names.fa, but the unpolished is assembly01.fa, so 05 means 4 rounds of polishing.
```
mkdir ~/dicty_assemblies/data/KGL29A/assemblies/bestAssemblies
mkdir ~/dicty_assemblies/data/KGL29A/assemblies/bestAssemblies/1_2021_Jan7
cp assembly05.names.fa ~/dicty_assemblies/data/KGL29A/assemblies/bestAssemblies/1_2021_Jan7/KGL29A_assembly_v1_flye1p4.fa
```
Now see [dicty_favoriteAssemblies.md](notes/dicty_favoriteAssemblies.md)


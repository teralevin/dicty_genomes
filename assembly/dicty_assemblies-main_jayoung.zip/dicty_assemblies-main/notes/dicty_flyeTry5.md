# Flye, fifth attempt, reads cleaned more again, without scaffolding

Do the assembly
```
cd ~/dicty_assemblies/data/KGL29A/assemblies/flye_try5_cleanerReads3_dont_scaffold

ln -s ../../fastqFiles/nanopore_withoutKlebsiella_round4/TL1-KGL29A_nanopore.nonKlebV4.fastq.gz .

# I pretty much go with defaults
# for sbatch, the default is we get 4Gb per CPU (24*4 = 96)
sbatch --cpus-per-task=24 -t 3-0 --job-name=flye5 --wrap="flye --nano-raw TL1-KGL29A_nanopore.nonKlebV4.fastq.gz --out-dir flye_try5_results --threads 24 --genome-size 34m"
```

It took ~30 mins. It's slightly bigger than flye_try4 (31508066 vs 31465344bp and 95 versus 90 contigs).
```
[2021-12-30 15:41:00] INFO: Assembly statistics:
        Total length:   31508066
        Fragments:      95
        Fragments N50:  2790136
        Largest frg:    4713225
        Scaffolds:      0
        Mean coverage:  46
```

xxxx

Index for mapping, GC content, etc, 
```
cd ~/dicty_assemblies/data/KGL29A/assemblies/flye_try5_cleanerReads3_dont_scaffold/flye_try5_results
../../../../../scripts_perl/GCcontentsimple.bioperl assembly.fasta

# index for BWA
mkdir assembly.fasta_indexForBWA
cd assembly.fasta_indexForBWA/
ln -s ../assembly.fasta .
module load BWA/0.7.17-GCC-10.2.0
bwa index assembly.fasta
module purge
cd ..

# index for IGV
module load IGV/2.8.6-Java-11
igvtools index assembly.fasta
module purge

# index for blast
mkdir assembly.fasta_indexForBlast
cd assembly.fasta_indexForBlast
ln -s ../assembly.fasta .
makeblastdb -in assembly.fasta -dbtype nucl -parse_seqids
cd ..

# index for picard
mkdir assembly.fasta_indexForPicard
cd assembly.fasta_indexForPicard
ln -s ../assembly.fasta .
module load picard/2.25.0-Java-11
java -jar $EBROOTPICARD/picard.jar CreateSequenceDictionary \
      R=assembly.fasta \
      O=assembly.txt.dict
module purge
cp ../assembly.fasta.fai .
cd ..
```




### RepeatMask
23.09 % bases masked
```
cd ~/dicty_assemblies/data/KGL29A/assemblies/flye_try5_cleanerReads3_dont_scaffold/flye_try5_results
~/dicty_assemblies/scripts_perl/runRepeatMasker.pl -t 24 -species=Dictyostelium assembly.fasta
```

## BUSCO
```
cd ~/dicty_assemblies/data/KGL29A/assemblies/flye_try5_cleanerReads3_dont_scaffold/flye_try5_results
~/dicty_assemblies/scripts_perl/runBUSCO.pl --lineage=eukaryota_odb10 assembly.fasta
mv assembly.fasta.BUSCO.* assembly.fasta_BUSCO/
```

### Quast

```
cd ~/dicty_assemblies/data/KGL29A/assemblies/flye_try5_cleanerReads3_dont_scaffold/flye_try5_results
~/dicty_assemblies/scripts_perl/runQuast.pl --options="-r ~/dicty_assemblies/data/resources/Dictyostelium_discoideum/dicty_chromosomal.names.fa" assembly.fasta
mv assembly.fasta_quast.quastRunLog.txt assembly.fasta.runquast.sh assembly.fasta_quast
```


### Promer and assemblytics

Try promer on masked seqs
```
cd ~/dicty_assemblies/data/KGL29A/assemblies/flye_try5_cleanerReads3_dont_scaffold/flye_try5_results/assembly.fasta_RepeatMasker
~/dicty_assemblies/scripts_perl/runPromer.pl assembly.fasta.masked
# assemblytics works with the promer output! I only want the plot, I don't care about the indel reports.
~/dicty_assemblies/scripts_perl/runAssemblytics.pl -anchor=100 assembly.fasta.masked_promer/ref_qry.delta
     xxxx running 45410718
```


### Blast first 1kb of each contig to NCBI

I want to see if there are more contaminants I should be screening out
```
cd ~/dicty_assemblies/data/KGL29A/assemblies/flye_try5_cleanerReads3_dont_scaffold/flye_try5_results
../../../../../scripts_perl/getFirstBitOfEachSeq.bioperl assembly.fasta

blastn -remote -db nr -task megablast -query assembly.first1000bp.fa -out assembly.first1000bp.fa.megablastnNR -num_descriptions 5 -num_alignments 5
    # actually finished surprisingly fast
# parse, keeping hits with e<10-5
~/dicty_assemblies/scripts_perl/blastparsenew.bioperl -interactive=0 assembly.first1000bp.fa.megablastnNR
```


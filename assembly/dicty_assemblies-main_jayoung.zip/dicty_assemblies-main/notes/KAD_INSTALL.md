# Install KAD

KAD estimates error rates in an assembly fasta file by comparing k-mers with those found in reads. See this [paper](https://academic.oup.com/nargab/article/2/3/lqaa075/5909520) and [github repo](https://github.com/liu3zhenlab/kad).

```
cd ~/dicty_assemblies/installations/KAD/
git clone https://github.com/liu3zhenlab/KAD.git
cd KAD
# even though installations is in .gitignore, I need to get rid of this to stop getting warnings
rm -rf .git  
```

I changed line 474 of `KADprofile.pl` to give the full path to Rscript executable: `/app/software/R/4.0.2-foss-2019b/bin/Rscript $tmpRscript`;

After some troubleshooting, I found a procedure that works:
```
mkdir ~/dicty_assemblies/data/KGL29A/assemblies/flye_try3_cleanerReads_dont_scaffold/flye_try3_results/assembly.fasta_KAD_try3/
cd ~/dicty_assemblies/data/KGL29A/assemblies/flye_try3_cleanerReads_dont_scaffold/flye_try3_results/assembly.fasta_KAD_try3/
ln -s ../assembly.fasta .

module purge
module load fhR/4.0.2-foss-2019b
module load Pandoc/2.10
export R_LIBS_USER=/home/jayoung/malik_lab_shared/linux_gizmo/R_packages/v_fh_4.0.2-foss-2019b

### for usage:
# perl ./KAD/KADprofile.pl

perl ~/dicty_assemblies/installations/KAD/KAD/KADprofile.pl --threads 4 --asm assembly.fasta --read ../../TL1_KGL29A_S322_R1.nonKleb2.fastq.gz --read ../../TL1_KGL29A_S322_R2.nonKleb2.fastq.gz
   # worked, but I got a warning that I am going to ignore (I think):
Warning message:
In grDevices::png(f) : unable to open connection to X11 display ''

module purge
```

See wrapper script `~/dicty_assemblies/scripts_perl/runKAD.pl`



# Initial MIGS assembly

## Get length and GC content for each contig in the initial MIGS assembly
```
cd ~/dicty_assemblies/data/KGL29A/assemblies/initialMIGSassembly
../../../../scripts_perl/GCcontentsimple.bioperl assembly.fasta 
../../../../scripts_perl/seqlength.bioperl assembly.fasta 
```
Total assembly length is 18,074,348 bp.

## Format it for various analyses
```
cd ~/dicty_assemblies/data/KGL29A/assemblies/initialMIGSassembly

# index for BWA
mkdir assembly.fasta_indexForBWA
cd assembly.fasta_indexForBWA/
ln -s ../assembly.fasta .
module load BWA/0.7.17-GCC-10.2.0
bwa index assembly.fasta
module purge
cd ..

# index for IGV
module load IGV/2.8.6-Java-11
igvtools index assembly.fasta
module purge

# index for blast
mkdir assembly.fasta_indexForBlast
cd assembly.fasta_indexForBlast
ln -s ../assembly.fasta .
makeblastdb -in assembly.fasta -dbtype nucl -parse_seqids
cd ..

# index for picard
mkdir assembly.fasta_indexForPicard
cd assembly.fasta_indexForPicard
ln -s ../assembly.fasta .
module load picard/2.25.0-Java-11
java -jar $EBROOTPICARD/picard.jar CreateSequenceDictionary \
      R=assembly.fasta \
      O=assembly.txt.dict
module purge
cp ../assembly.fasta.fai .
cd ..
```


## BUSCO
```
cd ~/dicty_assemblies/data/KGL29A/assemblies/initialMIGSassembly
~/dicty_assemblies/scripts_perl/runBUSCO.pl --lineage=eukaryota_odb10 assembly.fasta
mv assembly.fasta.BUSCO.* assembly.fasta_BUSCO/
```


## Quast
```
cd ~/dicty_assemblies/data/KGL29A/assemblies/initialMIGSassembly
~/dicty_assemblies/scripts_perl/runQuast.pl --options="-r ~/dicty_assemblies/data/resources/Dictyostelium_discoideum/dicty_chromosomal.names.fa" assembly.fasta
```

## take first 1kb of each contig, concatenate, and blast to NCBI, choose a few best-matching Klebsiella genomes

I want to see if there are more contaminants I should be screening out
```
cd ~/dicty_assemblies/data/KGL29A/assemblies/initialMIGSassembly
../../../../scripts_perl/getFirstBitOfEachSeq.bioperl assembly.fasta

../../../../scripts_perl/joinscaffold.bioperl assembly.first1000bp.fa 

blastn -remote -db nr -task megablast -query assembly.first1000bp.joined.fa -out assembly.first1000bp.joined.fa.megablastnNR -num_descriptions 1000 -num_alignments 1000
    xxx got some errors - might be some missing blast results
# parse, keeping hits with e<10-5
~/dicty_assemblies/scripts_perl/blastparsenew.bioperl -interactive=0 assembly.first1000bp.fa.blastnNR        

```

## RepeatMask
15.6 % bases masked
```
cd ~/dicty_assemblies/data/KGL29A/assemblies/initialMIGSassembly
~/dicty_assemblies/scripts_perl/runRepeatMasker.pl -t 24 -species=Dictyostelium assembly.fasta
```

## Promer and assemblytics
Try promer on masked seqs
```
cd ~/dicty_assemblies/data/KGL29A/assemblies/flye_try1_scaffold/flye_try1_results/assembly.fasta_RepeatMasker

~/dicty_assemblies/scripts_perl/runPromer.pl -sbatch=1 assembly.fasta.masked
~/dicty_assemblies/scripts_perl/runAssemblytics.pl -anchor=100 assembly.fasta.masked_promer/ref_qry.delta
    xxxx running 45424123
```
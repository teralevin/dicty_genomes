# Quast assembly QC

I wanted to get it to use fastq/bam input of Illumina reads mapped to teh reference, to give us error rates of the nanopore-based assemblies, but I think it is not actually capable of doing that. I used quast's test data to check it out:

```
cd ~/FH_fast_storage/temp/tempQuastStuff/git

## clone the quast repo to get the test data
git clone https://github.com/ablab/quast.git
cd quast/test_data

## run exact example provided by quast people. Using reads gives us coverage on the reference genome as well as the assemblies, and calls out any misjoins, but does not give any base-pair level statistics
module purge
module load QUAST/5.1.0rc1-foss-2020b
module load BWA/0.7.17-GCC-10.2.0
quast.py contigs_1.fasta contigs_2.fasta \
        -r reference.fasta.gz \
        -g genes.txt \
        -1 reads1.fastq.gz -2 reads2.fastq.gz \
        -o quast_test_output
module purge

## map same reads using BWA so I can try use sam input for quast rather than fastq.gz input
module load BWA/0.7.17-GCC-10.2.0
zcat reference.fasta.gz > reference.fasta
countFastqReads.pl reads*gz
# bwa mapped to reference
bwa index reference.fasta
bwa mem -t 4 reference.fasta reads1.fastq.gz reads2.fastq.gz > aln-pe_reference.sam
# bwa mapped to contigs_1.fasta
bwa index contigs_1.fasta
bwa mem -t 4 contigs_1.fasta reads1.fastq.gz reads2.fastq.gz > aln-pe_contigs1.sam
# bwa mapped to contigs_2.fasta
bwa index contigs_2.fasta
bwa mem -t 4 contigs_2.fasta reads1.fastq.gz reads2.fastq.gz > aln-pe_contigs2.sam
module purge

## try using the sam input mapped against reference. It gives us coverage on the reference genome, but not much else
module load QUAST/5.1.0rc1-foss-2020b
module load BWA/0.7.17-GCC-10.2.0
quast.py contigs_1.fasta contigs_2.fasta \
        -r reference.fasta.gz \
        -g genes.txt \
        --ref-sam aln-pe_reference.sam \
        -o quast_test_output_samRef
module purge


## try using the sam input mapped against the contigs - try only contigs_1
module load QUAST/5.1.0rc1-foss-2020b
module load BWA/0.7.17-GCC-10.2.0
quast.py contigs_1.fasta \
        -r reference.fasta.gz \
        -g genes.txt \
        --sam aln-pe_contigs1.sam \
        -o quast_test_output_samCtgs1
module purge
    # it's not reading the sam as a paired-end sam, although it is, so it doesn't get misjoins
    # Will not search Structural Variations (needs paired-end reads)
```


# POLCA assembly polishing

I tried using polca for assembly polishing - didn't get it to work, although I could have tried harder.

The first try I got an error coming from freebayes, when I was using an old-ish version I had installed (and I think made a link to in the Masurca install dir).

The second try, I loaded the freebayes module, but I got an error "ls: cannot access '/home/jayoung/malik_lab_shared/linux_gizmo/bin/freebayes': No such file or directory".  It wants freebayes to be within the Masurca install dir - I think I would load the module AND make a soft link to the scicomp freebayes within the masurca dir.

```
cd ~/dicty_assemblies/data/KGL29A/assemblies/flye_try3_cleanerReads_dont_scaffold

# links for the Illumina reads
ln -s ../../fastqFiles/illumina_withoutKlebsiella_min140_round2/TL1_KGL29A_S322_R1.nonKleb2.fastq.gz .
ln -s ../../fastqFiles/illumina_withoutKlebsiella_min140_round2/TL1_KGL29A_S322_R2.nonKleb2.fastq.gz .

cd flye_try3_results/assembly.fasta_POLCA
ln -s ../assembly.fasta .
# made a shell script by hand (assembly.fasta.polca.sh)
sbatch --job-name=polca --cpus-per-task=24 --wrap="bash ./assembly.fasta.polca.sh 2>&1 >> assembly.fasta.polca.log.txt"
```

# Racon assembly polishing

I didn't get very far with this. It wants only one file of sequences, so people usually interleave their fastq files.

```
mkdir ~/dicty_assemblies/data/KGL29A/assemblies/flye_try3_cleanerReads_dont_scaffold/flye_try3_results/assembly.fasta_RACON
cd ~/dicty_assemblies/data/KGL29A/assemblies/flye_try3_cleanerReads_dont_scaffold/flye_try3_results/assembly.fasta_RACON
ln -s ../assembly.fasta .

module load Racon/1.4.13-GCCcore-8.3.0

racon [options ...] <sequences> <overlaps> <target sequences>

module purge
```
# Resources

## Dictyostelium discoideum

### Dicty annotations

```
cd ~/dicty_assemblies/data/resources/Dictyostelium_discoideum/annotations_2022_Jan4
```

I got `dicty_gff3.zip` from [Dictybase download area](http://dictybase.org/db/cgi-bin/dictyBase/download/download.pl?area=gff3&ID=dicty_gff3.zip) and the protein, cds and non-coding seqs from [Dictybase sequence area](http://dictybase.org/db/cgi-bin/dictyBase/download/blast_databases.pl)

To clarify file types, I add .fa to the names of some:
```
mv dicty_noncoding dicty_noncoding.fa
mv dicty_primary_cds dicty_primary_cds.fa
mv dicty_primary_protein dicty_primary_protein.fa
```

`dicty_gff3.zip` unpacks to a very nested dir (`usr/local/dicty/data/gff3`), within which there's one gff3 per chromosome, so I do this: 
```
mv usr/local/dicty/data/gff3 .
rm -r usr dicty_gff3.zip
cd gff3
~/dicty_assemblies/scripts_perl/combineGffFiles.pl chromosome_M.gff   chromosome_2F.gff chromosome_3F.gff  chromosome_BF.gff chromosome_1.gff chromosome_2.gff chromosome_3.gff  chromosome_4.gff  chromosome_5.gff   chromosome_6.gff   chromosome_R.gff
mv combinedFiles.gff ../dicty_allChrs.gff
```
Note that the chromosome names in the gff files look like this: DDB0237465. I may want to convert them to e.g. chr1, like I did for the genome assembly fasta (below)

### Filtered set of intronless dicty proteins

`dicty_primary_protein.filteredIntronlessPeps.fa` contains 2296 'high quality' intronless proteins. See `~/dicty_assemblies/scripts_R/dicty_tblastn_discoideumgenes.Rmd` for how I got this file.



### Dicty genome assembly
Got the genomic sequence from [Dictybase](http://dictybase.org/db/cgi-bin/dictyBase/download/blast_databases.pl). Unpacked it to this file: `dicty_chromosomal.fa`

First I change the seq names to e.g. chr1 rather than DDB0232428. The original IDs stay in the seq headers. Then get lengths, GC content, format for mapping, etc.
```
cd ~/dicty_assemblies/data/resources/Dictyostelium_discoideum
../../../scripts_perl/changeDictyChrNames.bioperl dicty_chromosomal.fa 
../../../scripts_perl/seqlength.bioperl dicty_chromosomal.names.fa
../../../scripts_perl/GCcontentsimple.bioperl dicty_chromosomal.names.fa

# index for BWA
mkdir dicty_chromosomal.names.fa_indexForBWA
cd dicty_chromosomal.names.fa_indexForBWA/
ln -s ../dicty_chromosomal.names.fa .
module load BWA/0.7.17-GCC-10.2.0
bwa index dicty_chromosomal.names.fa
module purge
cd ..

# index for IGV
module load IGV/2.8.6-Java-11
igvtools index dicty_chromosomal.names.fa
module purge

# index for blast
mkdir dicty_chromosomal.names.fa_indexForBlast
cd dicty_chromosomal.names.fa_indexForBlast
ln -s ../dicty_chromosomal.names.fa .
makeblastdb -in dicty_chromosomal.names.fa -dbtype nucl -parse_seqids
cd ..

# index for picard
mkdir dicty_chromosomal.names.fa_indexForPicard
cd dicty_chromosomal.names.fa_indexForPicard
ln -s ../dicty_chromosomal.names.fa .
module load picard/2.25.0-Java-11
java -jar $EBROOTPICARD/picard.jar CreateSequenceDictionary \
      R=dicty_chromosomal.names.fa \
      O=dicty_chromosomal.names.dict
module purge
cp ../dicty_chromosomal.names.fa.fai .
cd ..
```

### RepeatMasker on genome assembly

I am using a slightly older RepeatMasker (2015), so that I can use the RepBase libraries I downloaded before they started charging money for that.

25.09% bases masked

```
cd ~/dicty_assemblies/data/resources/Dictyostelium_discoideum
~/dicty_assemblies/scripts_perl/runRepeatMasker.pl -t 24 -species=Dictyostelium dicty_chromosomal.names.fa
```



### BUSCO on genome assembly
```
cd ~/dicty_assemblies/data/resources/Dictyostelium_discoideum
~/dicty_assemblies/scripts_perl/runBUSCO.pl --lineage=eukaryota_odb10 dicty_chromosomal.names.fa
```

#### Quast on genome assembly

```
cd ~/dicty_assemblies/data/resources/Dictyostelium_discoideum
~/dicty_assemblies/scripts_perl/runQuast.pl --options="-r ~/dicty_assemblies/data/resources/Dictyostelium_discoideum/dicty_chromosomal.names.fa" dicty_chromosomal.names.fa
```

## Klebsiella (= dicty food)
Get a Klebsiella reference sequence so I can subtract out contaminating reads. 

### First round of Klebsiella subtraction:
A blast search on the NCBI website with the first ~2kb of the initial MIGS assembly's contig_1 has a 100% match to CP052309.1 ('Klebsiella pneumoniae strain E16KP0102 chromosome, complete genome') so I will use that to subtract reads

CP052309 is 5,458,571 bp long, 57.3% GC

Get CP052309 and format it for mapping, blasting, etc. I probably won't use most of theses indices but it's easier just to do it now while I'm here.

```
cd ~/dicty_assemblies/data/resources/klebsiella
echo 'CP052309' > CP052309acc.txt
../../../scripts_perl/getgenbankJY_eutils.bioperl CP052309acc.txt 
../../../scripts_perl/seqlength.bioperl CP052309acc.txt.fasta
../../../scripts_perl/GCcontentsimple.bioperl CP052309acc.txt.fasta

# index for BWA
mkdir CP052309acc.txt.fasta_indexForBWA
cd CP052309acc.txt.fasta_indexForBWA/
ln -s ../CP052309acc.txt.fasta .
module load BWA/0.7.17-GCC-10.2.0
bwa index CP052309acc.txt.fasta
module purge
cd ..

# index for IGV
module load IGV/2.8.6-Java-11
igvtools index CP052309acc.txt.fasta
module purge

# index for blast
mkdir CP052309acc.txt.fasta_indexForBlast
cd CP052309acc.txt.fasta_indexForBlast
ln -s ../CP052309acc.txt.fasta .
makeblastdb -in CP052309acc.txt.fasta -dbtype nucl -parse_seqids
cd ..

# index for picard
mkdir CP052309acc.txt.fasta_indexForPicard
cd CP052309acc.txt.fasta_indexForPicard
ln -s ../CP052309acc.txt.fasta .
module load picard/2.25.0-Java-11
java -jar $EBROOTPICARD/picard.jar CreateSequenceDictionary \
      R=CP052309acc.txt.fasta \
      O=CP052309acc.txt.dict
module purge
cp ../CP052309acc.txt.fasta.fai .
cd ..
```

### Second round of Klebsiella subtraction
My assemblies were a lot better after the first round of Klebsiella subtraction but I think I can do better. I blasted my flye_try2 assembly - first 1kb of each contig - against NR nt, and manually chose some more Klebsiella genomes and plasmids to subtract against (actually, one may be an E coli plasmid):

```
cd ~/dicty_assemblies/data/resources/klebsiella_moreStrains
klebsiella_moreStrains_accs.txt 
../../../scripts_perl/getgenbankJY_eutils.bioperl klebsiella_moreStrains_accs.txt 
../../../scripts_perl/seqlength.bioperl klebsiella_moreStrains_accs.txt.fasta
../../../scripts_perl/GCcontentsimple.bioperl klebsiella_moreStrains_accs.txt.fasta
```

Combine with the first Klebsiella genome I got, and format:
```
cd ~/dicty_assemblies/data/resources/combine_contaminants
cat ../klebsiella/CP052309acc.txt.fasta ../klebsiella_moreStrains/klebsiella_moreStrains_accs.txt.fasta > combined_contaminants_v1.fa

# index for BWA
mkdir combined_contaminants_v1.fa_indexForBWA
cd combined_contaminants_v1.fa_indexForBWA/
ln -s ../combined_contaminants_v1.fa .
module load BWA/0.7.17-GCC-10.2.0
bwa index combined_contaminants_v1.fa
module purge
cd ..

# index for IGV
module load IGV/2.8.6-Java-11
igvtools index combined_contaminants_v1.fa
module purge

# index for blast
mkdir combined_contaminants_v1.fa_indexForBlast
cd combined_contaminants_v1.fa_indexForBlast
ln -s ../combined_contaminants_v1.fa .
makeblastdb -in combined_contaminants_v1.fa -dbtype nucl -parse_seqids
cd ..

# index for picard
mkdir combined_contaminants_v1.fa_indexForPicard
cd combined_contaminants_v1.fa_indexForPicard
ln -s ../combined_contaminants_v1.fa .
module load picard/2.25.0-Java-11
java -jar $EBROOTPICARD/picard.jar CreateSequenceDictionary \
      R=combined_contaminants_v1.fa \
      O=combined_contaminants_v1.txt.dict
module purge
cp ../combined_contaminants_v1.fa.fai .
cd ..

```




### a third round of Klebsiella filtering

I used R to get another list of Klebsiella genomes to filter against (got it from the blast output of the remaining Klebsiella contigs)
```
cd ~/dicty_assemblies/data/resources/klebsiella_moreStrains2
../../../scripts_perl/getgenbankJY_eutils.bioperl klebsiella_moreStrains2_accs.txt 
../../../scripts_perl/seqlength.bioperl klebsiella_moreStrains2_accs.txt.fasta
../../../scripts_perl/GCcontentsimple.bioperl klebsiella_moreStrains2_accs.txt.fasta
```

Combine with the other Klebsiella genomes I got, and format:
```
cd ~/dicty_assemblies/data/resources/combine_contaminants
cat ../klebsiella/CP052309acc.txt.fasta ../klebsiella_moreStrains/klebsiella_moreStrains_accs.txt.fasta ../klebsiella_moreStrains2/klebsiella_moreStrains2_accs.txt.fasta > combined_contaminants_v2.fa

# index for BWA
mkdir combined_contaminants_v2.fa_indexForBWA
cd combined_contaminants_v2.fa_indexForBWA/
ln -s ../combined_contaminants_v2.fa .
module load BWA/0.7.17-GCC-10.2.0
bwa index combined_contaminants_v2.fa
module purge
cd ..

# index for IGV
module load IGV/2.8.6-Java-11
igvtools index combined_contaminants_v2.fa
module purge

# index for blast
mkdir combined_contaminants_v2.fa_indexForBlast
cd combined_contaminants_v2.fa_indexForBlast
ln -s ../combined_contaminants_v2.fa .
makeblastdb -in combined_contaminants_v2.fa -dbtype nucl -parse_seqids
cd ..

# index for picard
mkdir combined_contaminants_v2.fa_indexForPicard
cd combined_contaminants_v2.fa_indexForPicard
ln -s ../combined_contaminants_v2.fa .
module load picard/2.25.0-Java-11
java -jar $EBROOTPICARD/picard.jar CreateSequenceDictionary \
      R=combined_contaminants_v2.fa \
      O=combined_contaminants_v2.txt.dict
module purge
cp ../combined_contaminants_v2.fa.fai .
cd ..
```


### a fourth round of Klebsiella filtering


In flye4 assembly there is still one Klebsiella contig (`contig_117`). It matches various bacterial genomes including a Klebsiella grimontii genome (CP055991.1).

```
cd ~/dicty_assemblies/data/resources/klebsiella_moreStrains3
klebsiella_moreStrains3_accs.txt
../../../scripts_perl/getgenbankJY_eutils.bioperl klebsiella_moreStrains3_accs.txt 
../../../scripts_perl/seqlength.bioperl klebsiella_moreStrains3_accs.txt.fasta
../../../scripts_perl/GCcontentsimple.bioperl klebsiella_moreStrains3_accs.txt.fasta


```

Combine with the other Klebsiella genomes I got, and format:
```
cd ~/dicty_assemblies/data/resources/combine_contaminants
cat ../klebsiella/CP052309acc.txt.fasta ../klebsiella_moreStrains/klebsiella_moreStrains_accs.txt.fasta ../klebsiella_moreStrains2/klebsiella_moreStrains2_accs.txt.fasta ../klebsiella_moreStrains3/klebsiella_moreStrains3_accs.txt.fasta > combined_contaminants_v3.fa

# index for BWA
mkdir combined_contaminants_v3.fa_indexForBWA
cd combined_contaminants_v3.fa_indexForBWA/
ln -s ../combined_contaminants_v3.fa .
module load BWA/0.7.17-GCC-10.2.0
bwa index combined_contaminants_v3.fa
module purge
cd ..

# index for IGV
module load IGV/2.8.6-Java-11
igvtools index combined_contaminants_v3.fa
module purge

# index for blast
mkdir combined_contaminants_v3.fa_indexForBlast
cd combined_contaminants_v3.fa_indexForBlast
ln -s ../combined_contaminants_v3.fa .
makeblastdb -in combined_contaminants_v3.fa -dbtype nucl -parse_seqids
cd ..

# index for picard
mkdir combined_contaminants_v3.fa_indexForPicard
cd combined_contaminants_v3.fa_indexForPicard
ln -s ../combined_contaminants_v3.fa .
module load picard/2.25.0-Java-11
java -jar $EBROOTPICARD/picard.jar CreateSequenceDictionary \
      R=combined_contaminants_v3.fa \
      O=combined_contaminants_v3.txt.dict
module purge
cp ../combined_contaminants_v3.fa.fai .
cd ..

```
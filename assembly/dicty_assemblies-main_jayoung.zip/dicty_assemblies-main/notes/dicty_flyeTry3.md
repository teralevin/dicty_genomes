# Flye, third attempt, reads cleaned more, without scaffolding

Do the assembly
```
cd ~/dicty_assemblies/data/KGL29A/assemblies/flye_try3_cleanerReads_dont_scaffold

ln -s ../../fastqFiles/nanopore_withoutKlebsiella_round2/TL1-KGL29A_nanopore.nonKlebV2.fastq.gz .

# I pretty much go with defaults
# for sbatch, the default is we get 4Gb per CPU (24*4 = 96)
sbatch --cpus-per-task=24 -t 3-0 --job-name=flye3 --wrap="flye --nano-raw TL1-KGL29A_nanopore.nonKlebV2.fastq.gz --out-dir flye_try3_results --threads 24 --genome-size 34m"
```

It took ~30 mins. It's slightly smaller than flye_try2 (31573112bp versus 31,944,654 bp and 100 versus 132 contigs).
```
[2021-12-30 12:24:55] INFO: Assembly statistics:
        Total length:   31573112
        Fragments:      100
        Fragments N50:  4343819
        Largest frg:    4767655
        Scaffolds:      0
        Mean coverage:  46
```


# Index for mapping, GC content, etc, 
```
cd ~/dicty_assemblies/data/KGL29A/assemblies/flye_try3_cleanerReads_dont_scaffold/flye_try3_results
../../../../../scripts_perl/GCcontentsimple.bioperl assembly.fasta

# index for BWA
mkdir assembly.fasta_indexForBWA
cd assembly.fasta_indexForBWA/
ln -s ../assembly.fasta .
module load BWA/0.7.17-GCC-10.2.0
bwa index assembly.fasta
module purge
cd ..

# index for IGV
module load IGV/2.8.6-Java-11
igvtools index assembly.fasta
module purge

# index for blast
mkdir assembly.fasta_indexForBlast
cd assembly.fasta_indexForBlast
ln -s ../assembly.fasta .
makeblastdb -in assembly.fasta -dbtype nucl -parse_seqids
cd ..

# index for picard
mkdir assembly.fasta_indexForPicard
cd assembly.fasta_indexForPicard
ln -s ../assembly.fasta .
module load picard/2.25.0-Java-11
java -jar $EBROOTPICARD/picard.jar CreateSequenceDictionary \
      R=assembly.fasta \
      O=assembly.txt.dict
module purge
cp ../assembly.fasta.fai .
cd ..
```




## RepeatMask
20.9 % bases masked
```
cd ~/dicty_assemblies/data/KGL29A/assemblies/flye_try3_cleanerReads_dont_scaffold/flye_try3_results
~/dicty_assemblies/scripts_perl/runRepeatMasker.pl -t 24 -species=Dictyostelium assembly.fasta
```

## BUSCO
```
cd ~/dicty_assemblies/data/KGL29A/assemblies/flye_try3_cleanerReads_dont_scaffold/flye_try3_results
~/dicty_assemblies/scripts_perl/runBUSCO.pl --lineage=eukaryota_odb10 assembly.fasta
mv assembly.fasta.BUSCO.* assembly.fasta_BUSCO
```

## Quast

xxx with and without reference dicty assembly

```
cd ~/dicty_assemblies/data/KGL29A/assemblies/flye_try3_cleanerReads_dont_scaffold/flye_try3_results

# with ref
~/dicty_assemblies/scripts_perl/runQuast.pl --options="-r ~/dicty_assemblies/data/resources/Dictyostelium_discoideum/dicty_chromosomal.names.fa" assembly.fasta

# without ref
~/dicty_assemblies/scripts_perl/runQuast.pl --outsuffix=quastNoRef assembly.fasta


# without ref, with bam file of Illumina reads mapped back
~/dicty_assemblies/scripts_perl/runQuast.pl --options="--bam ../../../fastqFiles/illumina_withoutKlebsiella_min140_round2/map_to_flye3/TL1_KGL29A_S322_R1.nonKleb2.bwa.bam" --outsuffix=quastNoRef_Bam assembly.fasta
    # report.txt WAS identical to the quastNoRef report.txt
    # I now do get output in a reads_stats folder, but it does not seem useful. John might install a newer version for me

```


## Promer and assemblytics

Try promer on masked seqs
```
cd ~/dicty_assemblies/data/KGL29A/assemblies/flye_try3_cleanerReads_dont_scaffold/flye_try3_results/assembly.fasta_RepeatMasker

~/dicty_assemblies/scripts_perl/runPromer.pl -sbatch=1 assembly.fasta.masked
    # looking at ref_qry.coords.fix I think promer worked pretty well
# assemblytics works with the promer output! I only want the plot, I don't care about the indel reports.
~/dicty_assemblies/scripts_perl/runAssemblytics.pl -anchor=100 assembly.fasta.masked_promer/ref_qry.delta

## I also got mummerplot to work but the output is harder to interpret 
# (from a rhino01 session, so that X-forwarding operates)
cd assembly.fasta.masked_promer
module load gnuplot/5.4.1-GCCcore-10.2.0
~/dicty_assemblies/scripts_perl/mummerplot_JY.pl --medium --x11 -p ref_qry.delta.mummerplot ref_qry.delta 
module purge

```


## Blast first 1kb of each contig to NCBI

I want to see if there are more contaminants I should be screening out
```
cd ~/dicty_assemblies/data/KGL29A/assemblies/flye_try3_cleanerReads_dont_scaffold/flye_try3_results
../../../../../scripts_perl/getFirstBitOfEachSeq.bioperl assembly.fasta

blastn -remote -db nr -task megablast -query assembly.first1000bp.fa -out assembly.first1000bp.fa.megablastnNR -num_descriptions 5 -num_alignments 5
    # actually finished surprisingly fast
# parse, keeping hits with e<10-5
~/dicty_assemblies/scripts_perl/blastparsenew.bioperl -interactive=0 assembly.first1000bp.fa.megablastnNR

```

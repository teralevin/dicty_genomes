# 1_2021_Jan7. Flye1, after 4 rounds of polishing

dir = ~/dicty_assemblies/data/KGL29A/assemblies/bestAssemblies/1_2021_Jan7/KGL29A_assembly_v1_flye1p4.fa_KAD

file = KGL29A_assembly_v1_flye1p4.fa

seqnames look like this: KGL29Av1_contig_10_p4

## Fix seq names and file name so they'll be unique
```
~/dicty_assemblies/scripts_perl/changeFastaSeqNames_GENERIC.bioperl --prefix=KGL29Av1_ --find=pilon05 --replace=p4 KGL29A_assembly_v1_flye1p4.fa
mv KGL29A_assembly_v1_flye1p4.names.fa KGL29A_assembly_v1_flye1p4.fa
```
I share this with Tera and Mische in Dropbox

## KAD error estimates again, just to make sure I chose the assembly I intended to!

Num error k-mers = 1284190.   If I use conversion factor of 24, the error estimate is 1284190/24 = 53508 (rounded), so yes, this is what I was expecting

```
cd ~/dicty_assemblies/data/KGL29A/assemblies/bestAssemblies/1_2021_Jan7
~/dicty_assemblies/scripts_perl/runKAD.pl --t=20 --reads=../../../fastqFiles/illumina_withoutKlebsiella_min140/TL1_KGL29A_S322_R1.nonKleb.min140.fq.gz,../../../fastqFiles/illumina_withoutKlebsiella_min140/TL1_KGL29A_S322_R2.nonKleb.min140.fq.gz KGL29A_assembly_v1_flye1p4.fa
```

## Index for mapping, GC content, etc, 
```
cd ~/dicty_assemblies/data/KGL29A/assemblies/bestAssemblies/1_2021_Jan7

../../../../../scripts_perl/GCcontentsimple.bioperl KGL29A_assembly_v1_flye1p4.fa

# index for BWA
mkdir KGL29A_assembly_v1_flye1p4.fa_indexForBWA
cd KGL29A_assembly_v1_flye1p4.fa_indexForBWA/
ln -s ../KGL29A_assembly_v1_flye1p4.fa .
module load BWA/0.7.17-GCC-10.2.0
bwa index KGL29A_assembly_v1_flye1p4.fa
module purge
cd ..

# index for IGV
module load IGV/2.8.6-Java-11
igvtools index KGL29A_assembly_v1_flye1p4.fa
module purge

# index for blast
mkdir KGL29A_assembly_v1_flye1p4.fa_indexForBlast
cd KGL29A_assembly_v1_flye1p4.fa_indexForBlast
ln -s ../KGL29A_assembly_v1_flye1p4.fa .
makeblastdb -in KGL29A_assembly_v1_flye1p4.fa -dbtype nucl -parse_seqids
cd ..

# index for picard
mkdir KGL29A_assembly_v1_flye1p4.fa_indexForPicard
cd KGL29A_assembly_v1_flye1p4.fa_indexForPicard
ln -s ../KGL29A_assembly_v1_flye1p4.fa .
module load picard/2.25.0-Java-11
java -jar $EBROOTPICARD/picard.jar CreateSequenceDictionary \
      R=KGL29A_assembly_v1_flye1p4.fa \
      O=KGL29A_assembly_v1_flye1p4.dict
module purge
cp ../KGL29A_assembly_v1_flye1p4.fa.fai .
cd ..
```

## BUSCO
```
cd ~/dicty_assemblies/data/KGL29A/assemblies/bestAssemblies/1_2021_Jan7
~/dicty_assemblies/scripts_perl/runBUSCO.pl -t 16 --lineage=eukaryota_odb10 KGL29A_assembly_v1_flye1p4.fa
mv KGL29A_assembly_v1_flye1p4.fa.BUSCO.* KGL29A_assembly_v1_flye1p4.fa_BUSCO/
```

## Quast
```
cd ~/dicty_assemblies/data/KGL29A/assemblies/bestAssemblies/1_2021_Jan7
~/dicty_assemblies/scripts_perl/runQuast.pl --options="-r ~/dicty_assemblies/data/resources/Dictyostelium_discoideum/dicty_chromosomal.names.fa" KGL29A_assembly_v1_flye1p4.fa
```

## RepeatMask
21.61 % bases masked
```
cd ~/dicty_assemblies/data/KGL29A/assemblies/bestAssemblies/1_2021_Jan7
~/dicty_assemblies/scripts_perl/runRepeatMasker.pl -t 24 -species=Dictyostelium KGL29A_assembly_v1_flye1p4.fa
```

I got an 'alert' from RepeatMasker:
```
The following E coli IS elements could not be confidently clipped out:
  IS3#ARTEFACT in KGL29Av1_contig_100_p4: 481 - 1739
  IS3#ARTEFACT in KGL29Av1_contig_106_p4: 8452 - 8506
  IS5#ARTEFACT in KGL29Av1_contig_106_p4: 8691 - 8740
One or more E. coli IS elements were found:
  IS3#ARTEFACT in KGL29Av1_contig_116_p4: 9928 - 11173
These elements can be clipped out with the options is_clip or is_only.  The latter does not run the 'normal' Repeat
Masker routine and positions in the current
.out file will not correspond with the -is_only reconstructed sequence.
```
That's OK - all these contigs get filtered out by blobtools as Klebsiella contigs.

## Blast first 1kb of each contig to NCBI

I want to see if there are more contaminants I should be screening out
```
cd ~/dicty_assemblies/data/KGL29A/assemblies/bestAssemblies/1_2021_Jan7
../../../../../scripts_perl/getFirstBitOfEachSeq.bioperl KGL29A_assembly_v1_flye1p4.fa

sbatch --wrap="blastn -remote -db nr -task megablast -query KGL29A_assembly_v1_flye1p4.first1000bp.fa -out KGL29A_assembly_v1_flye1p4.first1000bp.fa.megablastnNR -num_descriptions 5 -num_alignments 5"
# parse, keeping hits with e<10-5
~/dicty_assemblies/scripts_perl/blastparsenew.bioperl -interactive=0 KGL29A_assembly_v1_flye1p4.first1000bp.fa.megablastnNR
```

## Promer and assemblytics
Try promer on masked seqs
```
cd ~/dicty_assemblies/data/KGL29A/assemblies/bestAssemblies/1_2021_Jan7/KGL29A_assembly_v1_flye1p4.fa_RepeatMasker
~/dicty_assemblies/scripts_perl/runPromer.pl -sbatch=1 KGL29A_assembly_v1_flye1p4.fa.masked
~/dicty_assemblies/scripts_perl/runAssemblytics.pl -anchor=100 KGL29A_assembly_v1_flye1p4.fa.masked_promer/ref_qry.delta
```

## Map reads back

I deleted these bam files later, once I started working with v2 (`rm  */map_to_bestAssembly_v1/*bam  */map_to_bestAssembly_v1/*bai`)

### illumina raw
```
cd ~/dicty_assemblies/data/KGL29A/fastqFiles/illumina_raw/map_to_bestAssembly_v1
~/dicty_assemblies/scripts_perl/run_bwa_mem_paired_GENERIC.pl --pair=1 --genome=/fh/fast/malik_h/user/jayoung/forOtherPeople/forTera/dicty_assemblies/data/KGL29A/assemblies/bestAssemblies/1_2021_Jan7/KGL29A_assembly_v1_flye1p4.fa_indexForBWA/KGL29A_assembly_v1_flye1p4.fa ../TL1_KGL29A_S322_R1_001.fastq.gz
# also get mean coverage per contig using samtools
module load SAMtools/1.11-GCC-10.2.0
samtools coverage TL1_KGL29A_S322_R1_001.bwa.bam > TL1_KGL29A_S322_R1_001.bwa.coverage.txt
module purge
```

### illumina noKleb
```
cd ~/dicty_assemblies/data/KGL29A/fastqFiles/illumina_withoutKlebsiella_min140/map_to_bestAssembly_v1
~/dicty_assemblies/scripts_perl/run_bwa_mem_paired_GENERIC.pl --pair=1 --genome=/fh/fast/malik_h/user/jayoung/forOtherPeople/forTera/dicty_assemblies/data/KGL29A/assemblies/bestAssemblies/1_2021_Jan7/KGL29A_assembly_v1_flye1p4.fa_indexForBWA/KGL29A_assembly_v1_flye1p4.fa ../TL1_KGL29A_S322_R1.nonKleb.min140.fq.gz
```

### nanopore raw
```
cd ~/dicty_assemblies/data/KGL29A/fastqFiles/nanopore_raw/map_to_bestAssembly_v1
~/dicty_assemblies/scripts_perl/run_minimap2_GENERIC.pl --genome=/fh/fast/malik_h/user/jayoung/forOtherPeople/forTera/dicty_assemblies/data/KGL29A/assemblies/bestAssemblies/1_2021_Jan7/KGL29A_assembly_v1_flye1p4.fa ../TL1-KGL29A_nanopore.fastq.gz
# also get mean coverage per contig using samtools
module load SAMtools/1.11-GCC-10.2.0
samtools coverage TL1-KGL29A_nanopore.minimap2.bam > TL1-KGL29A_nanopore.minimap2.coverage.txt
module purge
```

### nanopore noKleb
```
cd ~/dicty_assemblies/data/KGL29A/fastqFiles/nanopore_withoutKlebsiella/map_to_bestAssembly_v1
~/dicty_assemblies/scripts_perl/run_minimap2_GENERIC.pl --genome=/fh/fast/malik_h/user/jayoung/forOtherPeople/forTera/dicty_assemblies/data/KGL29A/assemblies/bestAssemblies/1_2021_Jan7/KGL29A_assembly_v1_flye1p4.fa ../TL1-KGL29A_nanopore.nonKleb.fastq.gz
```

## blobplot

I manually made a file called blobplot.run.sh (24 threads) and ran it:
```
cd ~/dicty_assemblies/data/KGL29A/assemblies/bestAssemblies/1_2021_Jan7/KGL29A_assembly_v1_flye1p4.fa_blobplot
ln -s ../KGL29A_assembly_v1_flye1p4.fa .
sbatch --job-name=blobtools -t 3-0 --cpus-per-task=24 --wrap="bash blobplot.run.sh"
mv slurm-45902174.out blobplot.log.txt
```

Get seqs for each blob-phylum:
```
~/dicty_assemblies/scripts_perl/assembly_splitByPhylum_blobplot.bioperl --assembly=KGL29A_assembly_v1_flye1p4.fa --blobout=KGL29A_assembly_v1_flye1p4.blobDB.table.txt
cd KGL29A_assembly_v1_flye1p4_seqsByPhylum
~/dicty_assemblies/scripts_perl/seqlength.bioperl  K*fa
~/dicty_assemblies/scripts_perl/getFirstBitOfEachSeq.bioperl K*fa
```

Do NCBI blasts for SOME of those blob-phyla (everything except Dicty and Klebsiella):
```
sbatch --wrap="blastn -remote -db nr -task megablast -query KGL29A_assembly_v1_flye1p4.Ascomycota.fa -out KGL29A_assembly_v1_flye1p4.Ascomycota.fa.megablastnNR -num_descriptions 5 -num_alignments 5"

sbatch --wrap="blastn -remote -db nr -task megablast -query KGL29A_assembly_v1_flye1p4.Ciliophora.fa -out KGL29A_assembly_v1_flye1p4.Ciliophora.fa.megablastnNR -num_descriptions 5 -num_alignments 5"

sbatch --wrap="blastn -remote -db nr -task megablast -query KGL29A_assembly_v1_flye1p4.Microsporidia.fa -out KGL29A_assembly_v1_flye1p4.Microsporidia.fa.megablastnNR -num_descriptions 5 -num_alignments 5"

sbatch --wrap="blastn -remote -db nr -task megablast -query KGL29A_assembly_v1_flye1p4.no-hit.fa -out KGL29A_assembly_v1_flye1p4.no-hit.fa.megablastnNR -num_descriptions 5 -num_alignments 5"

sbatch --wrap="blastn -remote -db nr -task megablast -query KGL29A_assembly_v1_flye1p4.Streptophyta.fa -out KGL29A_assembly_v1_flye1p4.Streptophyta.fa.megablastnNR -num_descriptions 5 -num_alignments 5"

sbatch --wrap="blastn -remote -db nr -task megablast -query KGL29A_assembly_v1_flye1p4.undef.fa -out KGL29A_assembly_v1_flye1p4.undef.fa.megablastnNR -num_descriptions 5 -num_alignments 5"

# parse, keeping hits with e<10-5
~/dicty_assemblies/scripts_perl/blastparsenew.bioperl -interactive=0 *.megablastnNR
```

Many contigs had no useful hits with megablastn, so I try blastn:
``` 
sbatch --wrap="blastn -remote -db nr -task blastn -query KGL29A_assembly_v1_flye1p4.no-hit.fa -out KGL29A_assembly_v1_flye1p4.no-hit.fa.blastnNR -num_descriptions 5 -num_alignments 5"

# a couple failed - pull them out for a look and blast again
~/dicty_assemblies/scripts_perl/splitfastafileextractoneseq.pl KGL29A_assembly_v1_flye1p4.no-hit.fa KGL29Av1_contig_130_p4
~/dicty_assemblies/scripts_perl/splitfastafileextractoneseq.pl KGL29A_assembly_v1_flye1p4.no-hit.fa KGL29Av1_contig_134_p4
sbatch --wrap="blastn -remote -db nr -task blastn -query KGL29Av1_contig_130_p4.fa -out KGL29Av1_contig_130_p4.fa.blastnNR -num_descriptions 5 -num_alignments 5"
sbatch --wrap="blastn -remote -db nr -task blastn -query KGL29Av1_contig_134_p4.fa -out KGL29Av1_contig_134_p4.fa.blastnNR -num_descriptions 5 -num_alignments 5"

# contig_134 keeps failing (web AND command-line) with excessive CPU error. Tried a few modifications. Got it working with word size 15 and e-value 0.00001 - no hits

# contig_134 is not repetitive:
~/dicty_assemblies/scripts_perl/runRepeatMasker.pl --sbatch=0 --species=Dictyostelium KGL29Av1_contig_134_p4.fa
    no repeats found
```

Doing some work in R, I make a table called `bestAssembly_1_2021_Jan7_manualContigClasses_startingPoint.txt` with the contigs I want to classify manually (keep/reject).  I edit that table in Excel: `bestAssembly_1_2021_Jan7_manualContigClasses.xlsx`.  From that, I make a plain-text list of the contigs to keep `bestAssembly_1_2021_Jan7_manualContigClasses_keepThese.txt`.  All those files are in `~/dicty_assemblies/notes`.

Combine the contigs I want to keep. 
``` 
cd ~/dicty_assemblies/data/KGL29A/assemblies/bestAssemblies/1_2021_Jan7/KGL29A_assembly_v1_flye1p4.fa_blobplot/KGL29A_assembly_v1_flye1p4_seqsByPhylum

mkdir sort_keepPhyla
cd sort_keepPhyla/
# first, the files for blob-phyla where I want to keep ALL contigs:
ln -s ../KGL29A_assembly_v1_flye1p4.Evosea.fa .
ln -s ../KGL29A_assembly_v1_flye1p4.Microsporidia.fa .
ln -s ../KGL29A_assembly_v1_flye1p4.Ciliophora.fa .

# next, the blob-phyla where I want to keep some but NOT all contigs:
mkdir ../sort_mixed_keepRejectPhyla
cd ../sort_mixed_keepRejectPhyla
cat ../KGL29A_assembly_v1_flye1p4.Streptophyta.fa ../KGL29A_assembly_v1_flye1p4.no-hit.fa > contigsToSort.fa

~/dicty_assemblies/scripts_perl/splitfastafileextractsomeseqs.bioperl contigsToSort.fa ~/dicty_assemblies/notes/bestAssembly_1_2021_Jan7_manualContigClasses_keepThese.txt
mv ~/dicty_assemblies/notes/bestAssembly_1_2021_Jan7_manualContigClasses_keepThese.txt.fa .

# now combine them:
cd ~/dicty_assemblies/data/KGL29A/assemblies/bestAssemblies/1_2021_Jan7/KGL29A_assembly_v1_flye1p4.fa_blobplot/KGL29A_assembly_v1_flye1p4_seqsByPhylum
cat sort_keepPhyla/KGL29A_assembly_v1_flye1p4.Evosea.fa sort_keepPhyla/KGL29A_assembly_v1_flye1p4.Ciliophora.fa  sort_keepPhyla/KGL29A_assembly_v1_flye1p4.Microsporidia.fa sort_mixed_keepRejectPhyla/bestAssembly_1_2021_Jan7_manualContigClasses_keepThese.txt.fa > KGL29A_assembly_v2_flye1p4_filt.fa

mkdir ~/dicty_assemblies/data/KGL29A/assemblies/bestAssemblies/2_2021_Jan10
cp KGL29A_assembly_v2_flye1p4_filt.fa ~/dicty_assemblies/data/KGL29A/assemblies/bestAssemblies/2_2021_Jan10
```

# 2_2021_Jan10. Flye1, after 4 rounds of polishing, filtered out contaminant contigs


## Index for mapping, GC content, etc, 
```
cd ~/dicty_assemblies/data/KGL29A/assemblies/bestAssemblies/2_2021_Jan10

~/dicty_assemblies/scripts_perl/GCcontentsimple.bioperl KGL29A_assembly_v2_flye1p4_filt.fa

# index for BWA
mkdir KGL29A_assembly_v2_flye1p4_filt.fa_indexForBWA
cd KGL29A_assembly_v2_flye1p4_filt.fa_indexForBWA/
ln -s ../KGL29A_assembly_v2_flye1p4_filt.fa .
module load BWA/0.7.17-GCC-10.2.0
bwa index KGL29A_assembly_v2_flye1p4_filt.fa
module purge
cd ..

# index for IGV
module load IGV/2.8.6-Java-11
igvtools index KGL29A_assembly_v2_flye1p4_filt.fa
module purge

# index for blast
mkdir KGL29A_assembly_v2_flye1p4_filt.fa_indexForBlast
cd KGL29A_assembly_v2_flye1p4_filt.fa_indexForBlast
ln -s ../KGL29A_assembly_v2_flye1p4_filt.fa .
makeblastdb -in KGL29A_assembly_v2_flye1p4_filt.fa -dbtype nucl -parse_seqids
cd ..

# index for picard
mkdir KGL29A_assembly_v2_flye1p4_filt.fa_indexForPicard
cd KGL29A_assembly_v2_flye1p4_filt.fa_indexForPicard
ln -s ../KGL29A_assembly_v2_flye1p4_filt.fa .
module load picard/2.25.0-Java-11
java -jar $EBROOTPICARD/picard.jar CreateSequenceDictionary \
      R=KGL29A_assembly_v2_flye1p4_filt.fa \
      O=KGL29A_assembly_v2_flye1p4_filt.dict
module purge
cp ../KGL29A_assembly_v2_flye1p4_filt.fa.fai .
cd ..
```

## BUSCO
Yes, I still have 94.1% complete buscos
```
cd ~/dicty_assemblies/data/KGL29A/assemblies/bestAssemblies/2_2021_Jan10
~/dicty_assemblies/scripts_perl/runBUSCO.pl -t 16 --lineage=eukaryota_odb10 KGL29A_assembly_v2_flye1p4_filt.fa
mv KGL29A_assembly_v2_flye1p4_filt.fa.BUSCO.* KGL29A_assembly_v2_flye1p4_filt.fa_BUSCO/
```

## Quast
```
cd ~/dicty_assemblies/data/KGL29A/assemblies/bestAssemblies/2_2021_Jan10
~/dicty_assemblies/scripts_perl/runQuast.pl --options="-r ~/dicty_assemblies/data/resources/Dictyostelium_discoideum/dicty_chromosomal.names.fa" KGL29A_assembly_v2_flye1p4_filt.fa
```
Don't think I lost anything useful

## RepeatMask
22.00 % bases masked
```
cd ~/dicty_assemblies/data/KGL29A/assemblies/bestAssemblies/2_2021_Jan10
~/dicty_assemblies/scripts_perl/runRepeatMasker.pl -t 24 -species=Dictyostelium KGL29A_assembly_v2_flye1p4_filt.fa
```

## Promer and assemblytics

Try promer on masked seqs
```
cd ~/dicty_assemblies/data/KGL29A/assemblies/bestAssemblies/2_2021_Jan10/KGL29A_assembly_v2_flye1p4_filt.fa_RepeatMasker
~/dicty_assemblies/scripts_perl/runPromer.pl -sbatch=1 KGL29A_assembly_v2_flye1p4_filt.fa.masked
~/dicty_assemblies/scripts_perl/runAssemblytics.pl -anchor=100 KGL29A_assembly_v2_flye1p4_filt.fa.masked_promer/ref_qry.delta
```

## Map reads back

### Illumina raw
```
cd ~/dicty_assemblies/data/KGL29A/fastqFiles/illumina_raw/map_to_bestAssembly_v2
~/dicty_assemblies/scripts_perl/run_bwa_mem_paired_GENERIC.pl --pair=1 --genome=/fh/fast/malik_h/user/jayoung/forOtherPeople/forTera/dicty_assemblies/data/KGL29A/assemblies/bestAssemblies/2_2021_Jan10/KGL29A_assembly_v2_flye1p4_filt.fa_indexForBWA/KGL29A_assembly_v2_flye1p4_filt.fa ../TL1_KGL29A_S322_R1_001.fastq.gz
# also get mean coverage per contig using samtools
module load SAMtools/1.11-GCC-10.2.0
samtools coverage TL1_KGL29A_S322_R1_001.bwa.bam > TL1_KGL29A_S322_R1_001.bwa.coverage.txt
module purge
```

### Illumina noKleb
```
cd ~/dicty_assemblies/data/KGL29A/fastqFiles/illumina_withoutKlebsiella_min140/map_to_bestAssembly_v2
~/dicty_assemblies/scripts_perl/run_bwa_mem_paired_GENERIC.pl --pair=1 --genome=/fh/fast/malik_h/user/jayoung/forOtherPeople/forTera/dicty_assemblies/data/KGL29A/assemblies/bestAssemblies/2_2021_Jan10/KGL29A_assembly_v2_flye1p4_filt.fa_indexForBWA/KGL29A_assembly_v2_flye1p4_filt.fa ../TL1_KGL29A_S322_R1.nonKleb.min140.fq.gz
```

### Nanopore raw
```
cd ~/dicty_assemblies/data/KGL29A/fastqFiles/nanopore_raw/map_to_bestAssembly_v2
~/dicty_assemblies/scripts_perl/run_minimap2_GENERIC.pl --genome=/fh/fast/malik_h/user/jayoung/forOtherPeople/forTera/dicty_assemblies/data/KGL29A/assemblies/bestAssemblies/2_2021_Jan10/KGL29A_assembly_v2_flye1p4_filt.fa ../TL1-KGL29A_nanopore.fastq.gz
# also get mean coverage per contig using samtools
module load SAMtools/1.11-GCC-10.2.0
samtools coverage TL1-KGL29A_nanopore.minimap2.bam > TL1-KGL29A_nanopore.minimap2.coverage.txt
module purge
```

### Nanopore noKleb
```
cd ~/dicty_assemblies/data/KGL29A/fastqFiles/nanopore_withoutKlebsiella/map_to_bestAssembly_v2
~/dicty_assemblies/scripts_perl/run_minimap2_GENERIC.pl --genome=/fh/fast/malik_h/user/jayoung/forOtherPeople/forTera/dicty_assemblies/data/KGL29A/assemblies/bestAssemblies/2_2021_Jan10/KGL29A_assembly_v2_flye1p4_filt.fa ../TL1-KGL29A_nanopore.nonKleb.fastq.gz
```

## blobplot

I manually made a file called blobplot.run.sh (24 threads) and ran it:
```
cd ~/dicty_assemblies/data/KGL29A/assemblies/bestAssemblies/2_2021_Jan10/KGL29A_assembly_v2_flye1p4_filt.fa_blobplot
ln -s ../KGL29A_assembly_v2_flye1p4_filt.fa .

sbatch --job-name=blobtools -t 3-0 --cpus-per-task=24 --wrap="bash blobplot.run.sh"
mv slurm-45910500.out blobplot.log.txt
```

## Get a file of the contigs I rejected by filtering:
Got a list of seqs using R: `KGL29A_assembly_v2_flye1p4_rejected.txt`, now get seqs:
```
~/dicty_assemblies/scripts_perl/splitfastafileextractsomeseqs.bioperl ../1_2021_Jan7/KGL29A_assembly_v1_flye1p4.fa KGL29A_assembly_v2_flye1p4_rejected.txt
mv KGL29A_assembly_v2_flye1p4_rejected.txt.fa KGL29A_assembly_v2_flye1p4_rejected.fa
rm KGL29A_assembly_v2_flye1p4_rejected.txt
```

## try MAKER gene prediction 

MAKER [website](https://www.yandell-lab.org/software/maker.html) and [wiki](https://weatherby.genetics.utah.edu/MAKER/wiki/index.php/Main_Page#Getting_started_with_MAKER)

```
cd ~/dicty_assemblies/data/KGL29A/assemblies/bestAssemblies/2_2021_Jan10/KGL29A_assembly_v2_flye1p4_filt.fa_MAKER
ln -s ../KGL29A_assembly_v2_flye1p4_filt.fa .

# generate control files, then edit them. I supply genome, dicty proteins, species name for RepeatMasker (Dictyostelium) and a few options about what to predict
maker -CTL
# then run it - it worked, took ~6hrs:
sbatch --job-name=maker -t 5-0 --cpus-per-task=24  --wrap="maker -cpus 24 maker_opts.ctl maker_bopts.ctl maker_exe.ctl"
mv slurm-46009910.out maker.log.txt
```

From wiki: "Once a MAKER run is finished the most important file to look at is the dpp_contig_master_datastore_index.log to see if there were any failures."

```
cd KGL29A_assembly_v2_flye1p4_filt.maker.output
more KGL29A_assembly_v2_flye1p4_filt_master_datastore_index.log
grep 'FINISHED' KGL29A_assembly_v2_flye1p4_filt_master_datastore_index.log  | wc
    ## seems fine, and it looked at all 70 contigs
```

From wiki: "at some point you're going to want merged files containing all of your output (i.e. a single GFF3 and FASTA file containing all genes). To do this we use two accessory scripts that come with MAKER: gff3_merge and fasta_merge. Both take the master_datastore_index.log file as input."

```
fasta_merge -d KGL29A_assembly_v2_flye1p4_filt_master_datastore_index.log
    # WARNING: Transcipt to protein mismatch for trnascan
gff3_merge -n -d KGL29A_assembly_v2_flye1p4_filt_master_datastore_index.log
    # the -n suppresses fasta output within the gff
# results:
KGL29A_assembly_v2_flye1p4_filt.all.gff
KGL29A_assembly_v2_flye1p4_filt.all.maker.proteins.fasta
KGL29A_assembly_v2_flye1p4_filt.all.maker.transcripts.fasta
KGL29A_assembly_v2_flye1p4_filt.all.maker.trnascan.transcripts.fasta

# also a version of the gff where I don't include the evidence:
gff3_merge -o KGL29A_assembly_v2_flye1p4_filt.all.noEvidence.gff -n -g -d KGL29A_assembly_v2_flye1p4_filt_master_datastore_index.log
```

Using grep, I see we have 9717 protein/transcript seqs and 392 tRNA seqs. The gff has 397941 lines (including repeatmasker, contig, etc)

Index the seqs for blast - turns out I need to shorten seq names to be tolerated by NCBI blast programs:
```
cd KGL29A_assembly_v2_flye1p4_filt.all.maker.predictions_blastIndices
ln -s ../KGL29A_assembly_v2_flye1p4_filt.all*fasta 

# seqnames are too long for blast programs, so I shorten first:
~/dicty_assemblies/scripts_perl/changeFastaSeqNames_GENERIC.bioperl --find="-exonerate_protein2genome-gene-" --replace="-gene-" KGL29A_assembly_v2_flye1p4_filt.all.maker.proteins.fasta
makeblastdb -in KGL29A_assembly_v2_flye1p4_filt.all.maker.proteins.names.fa -dbtype prot -parse_seqids

~/dicty_assemblies/scripts_perl/changeFastaSeqNames_GENERIC.bioperl --find="-exonerate_protein2genome-gene-" --replace="-gene-" KGL29A_assembly_v2_flye1p4_filt.all.maker.transcripts.fasta
makeblastdb -in KGL29A_assembly_v2_flye1p4_filt.all.maker.transcripts.names.fa -dbtype nucl -parse_seqids

# tRNA file requires three rounds of substitution:
~/dicty_assemblies/scripts_perl/changeFastaSeqNames_GENERIC.bioperl --find="-noncoding" KGL29A_assembly_v2_flye1p4_filt.all.maker.trnascan.transcripts.fasta
~/dicty_assemblies/scripts_perl/changeFastaSeqNames_GENERIC.bioperl --find="gene-" KGL29A_assembly_v2_flye1p4_filt.all.maker.trnascan.transcripts.names.fa
~/dicty_assemblies/scripts_perl/changeFastaSeqNames_GENERIC.bioperl --find="tRNA-" KGL29A_assembly_v2_flye1p4_filt.all.maker.trnascan.transcripts.names.names.fa
rm KGL29A_assembly_v2_flye1p4_filt.all.maker.trnascan.transcripts.names.fa KGL29A_assembly_v2_flye1p4_filt.all.maker.trnascan.transcripts.names.names.fa
mv KGL29A_assembly_v2_flye1p4_filt.all.maker.trnascan.transcripts.names.names.names.fa KGL29A_assembly_v2_flye1p4_filt.all.maker.trnascan.transcripts.names.fa

makeblastdb -in KGL29A_assembly_v2_flye1p4_filt.all.maker.trnascan.transcripts.names.fa -dbtype nucl -parse_seqids
```

Also change the gff file: shorten gene names so that the names match the fasta files.
```
#### change gff that includes evidence
# change protein/mRNA names:
~/dicty_assemblies/scripts_perl/substituteText_GENERIC.pl --print=10 --find="-exonerate_protein2genome-gene-" --replace="-gene-" --outsuffix=".names.gff" KGL29A_assembly_v2_flye1p4_filt.all.gff

# change tRNA names
~/dicty_assemblies/scripts_perl/substituteText_GENERIC.pl --print=10 --find="-noncoding" --outsuffix=".names.gff" KGL29A_assembly_v2_flye1p4_filt.all.names.gff
~/dicty_assemblies/scripts_perl/substituteText_GENERIC.pl --print=10 --find="-gene" --outsuffix=".names.gff" KGL29A_assembly_v2_flye1p4_filt.all.names.names.gff
~/dicty_assemblies/scripts_perl/substituteText_GENERIC.pl --print=10 --find="tRNA-" --outsuffix=".names.gff" KGL29A_assembly_v2_flye1p4_filt.all.names.names.names.gff

# tidy up
rm KGL29A_assembly_v2_flye1p4_filt.all.names.gff KGL29A_assembly_v2_flye1p4_filt.all.names.names.gff KGL29A_assembly_v2_flye1p4_filt.all.names.names.names.gff
mv KGL29A_assembly_v2_flye1p4_filt.all.names.names.names.names.gff KGL29A_assembly_v2_flye1p4_filt.all.names.gff


#### change gff that does not include evidence
# change protein/mRNA names:
~/dicty_assemblies/scripts_perl/substituteText_GENERIC.pl --print=10 --find="-exonerate_protein2genome-gene-" --replace="-gene-" --outsuffix=".names.gff" KGL29A_assembly_v2_flye1p4_filt.all.noEvidence.gff

# change tRNA names
~/dicty_assemblies/scripts_perl/substituteText_GENERIC.pl --print=10 --find="-noncoding" --outsuffix=".names.gff" KGL29A_assembly_v2_flye1p4_filt.all.noEvidence.names.gff
~/dicty_assemblies/scripts_perl/substituteText_GENERIC.pl --print=10 --find="-gene" --outsuffix=".names.gff" KGL29A_assembly_v2_flye1p4_filt.all.noEvidence.names.names.gff
~/dicty_assemblies/scripts_perl/substituteText_GENERIC.pl --print=10 --find="tRNA-" --outsuffix=".names.gff" KGL29A_assembly_v2_flye1p4_filt.all.noEvidence.names.names.names.gff

# tidy up
rm KGL29A_assembly_v2_flye1p4_filt.all.noEvidence.names.gff KGL29A_assembly_v2_flye1p4_filt.all.noEvidence.names.names.gff KGL29A_assembly_v2_flye1p4_filt.all.noEvidence.names.names.names.gff
mv KGL29A_assembly_v2_flye1p4_filt.all.noEvidence.names.names.names.names.gff KGL29A_assembly_v2_flye1p4_filt.all.noEvidence.names.gff
```

Sort and index the gffs.

Before I suppressed fasta from being included in the gff file, I got a mysterious error from igvtools sort: "Index 3 out of bounds for length 1"

```
module purge
module load IGV/2.9.4-Java-11 
igvtools sort KGL29A_assembly_v2_flye1p4_filt.all.names.gff  KGL29A_assembly_v2_flye1p4_filt.all.names.sorted.gff
igvtools index KGL29A_assembly_v2_flye1p4_filt.all.names.sorted.gff
igvtools sort KGL29A_assembly_v2_flye1p4_filt.all.noEvidence.names.gff  KGL29A_assembly_v2_flye1p4_filt.all.noEvidence.names.sorted.gff
igvtools index KGL29A_assembly_v2_flye1p4_filt.all.noEvidence.names.sorted.gff
module purge


```

Get rid of the repeatmasker lines from the gffs - I don't need them. Re-index.
```
grep -v 'repeatmasker' KGL29A_assembly_v2_flye1p4_filt.all.names.sorted.gff >  KGL29A_assembly_v2_flye1p4_filt.all.names.sorted.noRM.gff
grep -v 'repeatmasker' KGL29A_assembly_v2_flye1p4_filt.all.noEvidence.names.sorted.gff >  KGL29A_assembly_v2_flye1p4_filt.all.noEvidence.names.sorted.noRM.gff

module load IGV/2.9.4-Java-11 
igvtools index KGL29A_assembly_v2_flye1p4_filt.all.names.sorted.noRM.gff
igvtools index KGL29A_assembly_v2_flye1p4_filt.all.noEvidence.names.sorted.noRM.gff
module purge
```


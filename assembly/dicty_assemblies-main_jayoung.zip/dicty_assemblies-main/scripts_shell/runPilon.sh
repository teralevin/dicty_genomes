#!/bin/bash
source /app/lmod/lmod/init/profile

### stole this script from  https://bioinformaticsworkbook.org/dataAnalysis/GenomeAssembly/Iterate_Pilon_Genome_Polishing.html#gsc.tab=0
# the "I" in this code is Rick Masonbrink, Iowa State

# modified to use bwa not hisat2

# it can be used to iterate mutiple rounds of pilon runs

## usage:
# sh runPilon.sh DIR GENOME R1_FQ R2_FQ THREADS


######################

# Create unix variables
DIR="$1"
GENOME="$2"
R1_FQ="$3"
R2_FQ="$4"
THREADS="$5"

# set up a temp dir
MY_UNIQUE_TAG=`date +%N`
MY_TEMP_DIR=${DELETE30}/malik_h/${GENOME%.*}.${MY_UNIQUE_TAG}.tmpdir
mkdir ${MY_TEMP_DIR}

echo 'Using temp dir:'
echo ${MY_TEMP_DIR}

echo 'Using this many threads:'
echo ${THREADS}

echo 'bwa command will be:'
echo 'bwa mem -t ${THREADS} -Y ${GENOME} $R1_FQ $R2_FQ | samtools view --threads ${THREADS} -Sb - | samtools sort -@ ${THREADS} -O bam -T ${MY_TEMP_DIR} > ${GENOME%.*}.${R1_FQ%.*}_sorted.bam'


# I don't think there is a good way to capture both sterr and stdout from individual commands within my bash script so it is just going to do in the slurm file.

# Index the genome and perform short read mapping using bwa. Also convert sam to bam, sort, and index. 
## %.* removes anything after the . (including the .)
module load BWA/0.7.17-GCC-10.2.0
module load SAMtools/1.11-GCC-10.2.0
bwa index ${GENOME}
bwa mem -t ${THREADS} -Y ${GENOME} $R1_FQ $R2_FQ | samtools view --threads ${THREADS} -Sb - | samtools sort -@ ${THREADS} -O bam -T ${MY_TEMP_DIR} > ${GENOME%.*}.${R1_FQ%.*}_sorted.bam
samtools index ${GENOME%.*}.${R1_FQ%.*}_sorted.bam
module purge

# I am running pilon here using the max memory available to me, using a temp folder I created above. Pilon can also have issues with RAM usage, so in this case I cut my thread usage to half of those available. My chunk size is also smaller than default, again catering to potential ram issues that would affect iteration
# I used to include the following line, but "--threads argument no longer supported; ignoring!"
# --threads ${THREADS}
module load Java/11.0.2 
java -Xmx200g -Djava.io.tmpdir=${MY_TEMP_DIR} -jar /home/jayoung/malik_lab_shared/linux_gizmo/bin/pilon-1.24.jar --genome ${GENOME} --frags  ${GENOME%.*}.${R1_FQ%.*}_sorted.bam --output ${GENOME%.*}.pilon --outdir ${DIR} --changes --fix snps,indels 
module purge

# Tidy up, if we know the loop is working
rm *bam *bai

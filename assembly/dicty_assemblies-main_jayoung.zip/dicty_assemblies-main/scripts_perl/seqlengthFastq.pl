#!/usr/bin/perl

use warnings;
use strict;
use PerlIO::gzip;

#### writes out length of each seq, and total seq length in each file
#### cannot use bioperl on output of cutadapt, because some reads can have zero length and that crashes bioperl.  using plain perl instead.

############

foreach my $file (@ARGV){
    if (!-e $file) {
        die "\n\nterminating - file $file does not exist\n\n";
    }
    print "file $file\n";
    
    my $total = 0;
    my $out = "$file".".lengths";
    if ($file =~ m/\.gz$|\.gzip$/) {
        open IN, "<:gzip", "$file" or die $!;
    } else {
        open (IN, "< $file");
    }
    my @lines = <IN>;
    close IN;
    my $numLines = @lines;
    
    open (OUT, "> $out");
    my $lineCount = 0; # cycles 1-4
    my $seqname; my $length;
    SEQLOOP: foreach my $line (@lines) {
        $lineCount++;
        if ($lineCount == 1) { 
            chomp $line; $seqname = $line; 
            if ($seqname =~ m/\s/) { $seqname = (split /\s/, $seqname)[0]; }
            $seqname =~ s/^@//;
        }
        if ($lineCount == 2) { 
            chomp $line; $length = length $line; 
            $total += $length;
            print OUT "$seqname\t$length\n";
        }
        if ($lineCount == 4) { 
            $lineCount = 0; undef $seqname; undef $length;
        }
    } 
    print OUT "Total\t$total\n";
    close OUT;
}


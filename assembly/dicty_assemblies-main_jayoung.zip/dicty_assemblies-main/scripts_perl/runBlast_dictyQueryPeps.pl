#!/usr/bin/perl

use warnings;
use strict;
use Getopt::Long;

####### runBlast_dictyQueryPeps.pl genome assembly files
## blasts same query seqs against each assembly

my $query = "~/dicty_assemblies/data/resources/Dictyostelium_discoideum/annotations_2022_Jan4/dicty_primary_protein.filteredIntronlessPeps.fa"; 
my $numHitsToKeep = 5;

my $use_sbatch = 1;
my $numThreads = 12;
my $walltime = "3-0";
my $debug = 0;

GetOptions("query=s"       => \$query,
           "hits=i"        => \$numHitsToKeep,           # '--t 4' to use 4 threads
           "t=i"           => \$numThreads,           # '--t 4' to use 4 threads
           "sbatch=i"      => \$use_sbatch,
           "wall=s"        => \$walltime,             # '--wall 0-6' to specify 6 hrs
           "debug"         => \$debug                 # '--debug' to just test
           ) or die "\n\nterminating - unknown option(s) specified on command line\n\n"; 


# tblastn -query ~/dicty_assemblies/data/resources/Dictyostelium_discoideum/annotations_2022_Jan4/dicty_primary_protein.filteredIntronlessPeps.fa -db assembly.fasta_indexForBlast/assembly.fasta -num_threads 4 -num_descriptions 5 -num_alignments 5 -out dicty_intronlessPeps.tblastn_assembly


#####################
if ($use_sbatch == 1) {print "\n\nUsing sbatch to parallelize\n\n";}

foreach my $file (@ARGV) {
    if (!-e $file) {
        die "\n\nterminating - assembly file $file does not exist\n\n";
    }
    print "\n#### working on assembly $file\n";
    my $fileStem = $file; $fileStem =~ s/\.fasta$//; $fileStem =~ s/\.fa$//;
    my $outfile = "dicty_intronlessPeps.tblastn_$fileStem";
    my $logfile = "$outfile.log.txt";
    
    my $makeblastdb = "makeblastdb -in $file -dbtype nucl -parse_seqids";
    if (!-e "$file.nhr") {
        print "    indexing for blast with this command:\n        $makeblastdb";
        system($makeblastdb);
    }
    
    my $blast = "tblastn -query $query -db $file -num_threads $numThreads -num_descriptions $numHitsToKeep -num_alignments $numHitsToKeep -out $outfile";
    open (LOG, "> $logfile");
    print LOG "\n$blast\n";
    close LOG;
    
    my $command;
    if ($use_sbatch == 1) {
        $command = "sbatch --job-name=blast -t $walltime --cpus-per-task=$numThreads --wrap=\"$blast 2>&1 >> $logfile\"";
    } else {
        $command = "$command 2>&1 >> $logfile";
    }
    print "command $command\n\n";
    if ($debug == 0) { system($command); }
}

if (($use_sbatch == 1) & ($debug == 0)) {
    print "\n\nSet all jobs going - use sq command to monitor whether there are still any blast commands running\n\n";
}


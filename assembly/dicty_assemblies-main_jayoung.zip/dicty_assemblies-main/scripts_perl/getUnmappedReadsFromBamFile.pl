#!/usr/bin/perl

use warnings;
use strict;
use Getopt::Long;

####### getUnmappedReadsFromBamFile.pl bamfile(s)
# pipes together two or three samtools commands to extract the unmapped reads.
# it's different for paired and single end samples

my $paired=1;
my $numThreads = 1;
my $use_sbatch = 1;
my $walltime = "0-4";
my $debug = 0;

GetOptions("pair=i"        => \$paired,
           "t=i"           => \$numThreads,     # '--t 4' to use 4 threads           
           "sbatch=i"      => \$use_sbatch,
           "wall=s"        => \$walltime,       # '--wall 0-6' to specify 6 hrs
           "debug"         => \$debug           # '--debug' to just test, not actually run
           ) or die "\n\nterminating - unknown option(s) specified on command line\n\n"; 



#####################
if ($paired==1) {
    print "\n\nNOTE - assuming this bam file contains paired-end reads - if that's not right, add --pair=0 to the command-line\n\n";
}

foreach my $file (@ARGV) {
    if (!-e $file) {
        die "\n\nterminating - file $file does not exist\n\n";
    }
    if ($file !~ m/\.bam$/) {
        die "\n\nterminating - file $file does not seem to be a bam file\n\n";
    }
    
    print "## working on file $file\n";
    my $shellScriptFileName = $file;
    $shellScriptFileName =~ s/\.bam$//;
    my $logFileName = $shellScriptFileName; 
    $shellScriptFileName .= ".getUnmapped.sh";
    $logFileName .= ".getUnmapped.log.txt";
    if (-e $shellScriptFileName) {
        print "    skipping file $file as shell script exists already: $shellScriptFileName\n";
        next;
    }
    
    open (COMMAND, "> $shellScriptFileName");
    print COMMAND "#!/bin/bash\n";
    print COMMAND "source /app/lmod/lmod/init/profile\n";
    print COMMAND "module load SAMtools/1.11-GCC-10.2.0\n";
    if ($paired == 1) {
        printPairedEndCommands($file);
    } else {
        printSingleEndCommands($file);
    }
    print COMMAND "module purge\n";
    close COMMAND;
    
    my $command;
    if ($use_sbatch == 1) {
        $command = "sbatch --job-name=getUnmapped -t $walltime --wrap=\"bash ./$shellScriptFileName >> $logFileName\"";
    } else {
        $command = "bash ./$shellScriptFileName >> $logFileName";
    }
    print "command $command\n\n";
    if ($debug == 0) { system($command); }
}

########

sub printPairedEndCommands {
    my $file = $_[0];
    my $outStem = $file; $outStem =~ s/\.bam//;
    # the 2>&1 at the end seems to be needed so that I can capture the output. 
    print COMMAND "samtools view -h -f 4 $file | samtools sort -u -n | samtools fastq -1 $outStem.unmapped_R1.fastq -2 $outStem.unmapped_R2.fastq -0 /dev/null -s $outStem.unmapped_singletons.fastq -n 2>&1 >> $outStem.getUnmapped.log.txt\n";
    print COMMAND "gzip $outStem.unmapped_R1.fastq\n";
    print COMMAND "gzip $outStem.unmapped_R2.fastq\n";
    print COMMAND "gzip $outStem.unmapped_singletons.fastq\n";
}

sub printSingleEndCommands {
    my $file = $_[0];
    my $outStem = $file; $outStem =~ s/\.bam//;
    print COMMAND "samtools view -h -f 4 $file | samtools fastq -0 $outStem.unmapped.fastq -s /dev/null -n 2>&1 >> $outStem.getUnmapped.log.txt\n"; #  
    print COMMAND "gzip $outStem.unmapped.fastq\n";

}
#!/usr/bin/perl

use warnings;
use strict;
use Bio::SeqIO;

#usage: splitfastafileextractoneseq.pl bigfilename seqofinterest

if (@ARGV != 2) {
    die "\n\nterminating - please specify: (a) sequence file and (b) name of the sequence you want\n\n";
}

my $bigseqfile = $ARGV[0];
my $seqofinterest = $ARGV[1];

if (!-e $bigseqfile) {
    die "\n\nterminating - cannot find sequence file $bigseqfile\n\n";
}

print "\nIf this script runs too slowly, consider indexing the databse using makeblastdb and using splitfastafileextractonesequsingblastdbcmd.pl instead\n\n";

my $out = "$seqofinterest.fa";
$out =~ s/\//_/g;
$out =~ s/\:/_/g;
$out =~ s/\|/_/g;
$out =~ s/[()]/_/g;

my $seqOUT = Bio::SeqIO->new(-file=>"> $out", -format=>"fasta");
my $seqIN = Bio::SeqIO->new(-file=>"$bigseqfile", -format=>"fasta");
while (my $seq = $seqIN->next_seq) {
    my $seqname = $seq->id();
    if ($seqname eq $seqofinterest) {
        $seqOUT->write_seq($seq);
        die "\n\nFound sequence $seqname - finished\n\n";
    }
}

print "\n\nLooks like seq $seqofinterest was not in $bigseqfile\n\n";

#!/usr/bin/perl

use warnings;
use strict;
use Getopt::Long;

####### runFastqcOnEachFileOrPairIndividually.pl fastqFile(s) (can be gzipped)
### runs fastqc on all fastq.gz files together. 
### see also runFastqcOnAllFilesTogether.pl
### (see also a more complicated version of this script called runFastqcFigureOutSampleGroupings.pl that can take a longer list of fastq.gz files and tries to figure out which files are from which sample, and also splits files for each sample running R1 and R2 separately)


########## some variables to set:

### defaults

### output files will go here:
my $outDir = ".";

my $fastqcOptions = "";

##### for Hutch fastq files, where I have several for each library, I'll want this set to  --casava - it'll combine 001 002 etc files (I used to call this variable combineCasavaFiles)
my $combineCasavaFiles = "";
#my $combineCasavaFiles = " --casava";


### will screen for these sequences:
my $contaminantsFile = "/fh/fast/malik_h/user/jayoung/forOtherPeople/forTera/dicty_assemblies/data/resources/miscellaneous/variousAdaptersBothStrands.fa.txt";

my $use_sbatch = 1;
my $numThreads = 4;
my $walltime = "3-0";
my $debug = 0;

### 
GetOptions("out=s"         => \$outDir, 
           "options=s"     => \$fastqcOptions, 
           "combine001=s"  => \$combineCasavaFiles, 
           "screenSeqs=s"  => \$contaminantsFile, 
           "t=i"           => \$numThreads,           # '--t 4' to use 4 threads
           "sbatch=i"      => \$use_sbatch,
           "wall=s"        => \$walltime,             # '--wall 0-6' to specify 6 hrs
           "debug"         => \$debug                 # '--debug' to just test
           ) or die "\n\nterminating - unknown option(s) specified on command line\n\n"; 


#### example command
### fastqc --casava --outdir Sample_1_Control_DNA/R2 --format fastq --threads 3 --contaminants /fh/fast/malik_h/user/jayoung/general_notes/NextGenSeqStuff/TruSeqAdaptersFeb28_2013_plusSomeTrimmedVersions.bothStrands.fa.txt ../FASTQ_files/Sample_1_Control_DNA/*R2*gz

########## end of variables to set

#####################

if (!-e $outDir) {
    die "\n\nterminating - script specifies outDir $outDir but it does not exist\n\n";
}

if (!-e $contaminantsFile) {
    die "\n\nterminating - script specifies contaminantsFile $contaminantsFile but it does not exist\n\n";
}

if ($use_sbatch == 1) {
    print "\n\nUsing sbatch to parallelize\n\n";
}

#### double-check that the $contaminantsFile is in tab-delimited text format not in fasta format
if ($contaminantsFile =~ m/\.fa$|\.fasta$/) {
    die "\n\nterminating - make sure $contaminantsFile is not in fasta format - should be tab-delimited text\n\n";
}

my $logFile = "$outDir/runFastqcLogFile.txt";
open (OUT, "> $logFile");
foreach my $file (@ARGV) {
    #### run fastqc
    my $thisOutdir = $file; $thisOutdir =~ s/\.fastq\.gz//;
    if ($thisOutdir =~ m/\//) { $thisOutdir = (split /\//, $thisOutdir)[-1]; }
    $thisOutdir = "$outDir/$thisOutdir" . "_fastqc";
    if (!-e $thisOutdir) {system "mkdir $thisOutdir";}
    
    ## could check here for existing outfile, but have not implemented that 
    my $command = "fastqc $fastqcOptions $combineCasavaFiles --outdir $thisOutdir --format fastq --threads $numThreads --contaminants $contaminantsFile $file";
    if ($use_sbatch == 1) {
        $command = "/bin/bash -c \\\"source /app/lmod/lmod/init/profile; module load FastQC/0.11.9-Java-11 ; $command\\\"";

        $command = "sbatch -t 0-3 --cpus-per-task=$numThreads --job-name=fastqc --wrap=\"$command\"";
    }
    print "command $command\n\n";
    print OUT "command:\n$command\n\n";
    if ($debug == 0) { system($command); }
}

if ($use_sbatch == 1) {
    print "\n\nSet all jobs going - use sq command to monitor whether there are still any fastqc commands running\n\n";
}

close OUT;

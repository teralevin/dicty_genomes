#!/usr/bin/perl
use warnings;
use strict;
use Getopt::Long;

####### runQuast.pl fastafile(s)
### runs a command like this:     quast.py --threads 4 -o assembly.fa_quast assembly.fa
### by generating a shell script and using sbatch to run it on a cluster

### set defaults
my $quastOptions = "";
my $outdirSuffix = "quast";
my $numThreads = 4;
my $use_sbatch = 1;
my $walltime = "0-4";
my $debug = 0;

GetOptions("options=s"     => \$quastOptions,
           "outsuffix=s"   => \$outdirSuffix,
           "t=i"           => \$numThreads,     # '--t 4' to use 4 threads           
           "sbatch=i"      => \$use_sbatch,
           "wall=s"        => \$walltime,       # '--wall 0-6' to specify 6 hrs
           "debug"         => \$debug           # '--debug' to just test, not actually run
           ) or die "\n\nterminating - unknown option(s) specified on command line\n\n"; 



#####################

foreach my $file (@ARGV) {
    if (!-e $file) {
        die "\n\nterminating - file $file does not exist\n\n";
    }
    my $outdir = $file . "_" . $outdirSuffix;
    if (-e $outdir) {
        print "skipping $file - outdir $outdir exists already\n\n";
        next;
    }
    my $logfile = "$file.$outdirSuffix.runLog.txt";

    my $shellScript = "$file.$outdirSuffix.runScript.sh";
    open (SH, "> $shellScript");
    print SH "#!/bin/bash\n";
    print SH "source /app/lmod/lmod/init/profile\n";
    print SH "module purge\n"; 
    print SH "module load QUAST/5.1.0rc1-foss-2020b\n"; 
    
    print SH "quast.py $quastOptions --threads $numThreads -o $outdir $file > $logfile\n";
    print SH "module purge\n";
    print SH "mv $logfile $outdir\n";
    print SH "mv $shellScript $outdir\n";
    close SH;
    
    my $command = "./$shellScript";
    if ($use_sbatch == 1) {
        $command = "sbatch --cpus-per-task=$numThreads -t $walltime --job-name=quast $command";
    } 
    print "command $command\n\n";
    if ($debug == 0) { system($command); }
}

if ($use_sbatch == 1) {
    print "\n\nSet all jobs going - use sq command to monitor whether there are still any quast commands running\n\n";
}


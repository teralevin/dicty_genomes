#!/usr/bin/perl

use warnings;
use strict;

## usage: getReadCountsPerChrSamtools.pl bamfile(s).bam

########### runs samtools idxstats to count reads mapping to each chromosome - not using srun for now, as this seems fast

my $figureOutSampleName = "no";
#my $figureOutSampleName = "yes";

## outfile will be figured out from this.  Might need to use different strategy sometimes
my $sampleNameField = 8; ### 0-based.  when I split file name on "/" which field will contain sample name


### runs samtools idxstats on each bam file specified on command line

foreach my $file (@ARGV) {
    print "\nrunning samtools idxstats on file $file\n";
    
    my $sampleName = $file;
    if ($figureOutSampleName eq "yes") { $sampleName = (split /\//, $file)[$sampleNameField];}
    if (!defined $sampleName) {
        die "sampleName is undefined - something's wrong\n";
    }
    my $outfile = "$sampleName.chrCounts";
    print "outfile will be called $outfile\n\n";

    if (-e $outfile) {
        print "outfile $outfile exists already\n";
        next;
    }
    system("samtools idxstats $file > $outfile");
    print "done running samtools\n";

}


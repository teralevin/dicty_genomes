#!/usr/bin/perl

use warnings;
use strict;
use Getopt::Long;
use Cwd;

###### runs Assemblytics on each file specified on the command line

my $unique_anchor_length = 200;
my $min_variant_size = 1;
my $max_variant_size = 10000;
my $use_sbatch = 1;
my $numThreads = 12;
my $walltime = "3-0";
my $debug = 0;

GetOptions("anchor=i"      => \$unique_anchor_length,
           "min=i"         => \$min_variant_size,
           "max=i"         => \$max_variant_size,
           "t=i"           => \$numThreads,           # '--t 4' to use 4 threads
           "sbatch=i"      => \$use_sbatch,
           "wall=s"        => \$walltime,             # '--wall 0-6' to specify 6 hrs
           "debug"         => \$debug                 # '--debug' to just test
           ) or die "\n\nterminating - unknown option(s) specified on command line\n\n"; 

# module load fhR/4.0.2-foss-2019b
# module load Python/3.7.4-foss-2019b-fh1
# Assemblytics ref_qry.delta ref_qry.delta.assemblytics 200 1 10000
# mv ref_qry.delta.assemblytics.* ref_qry.delta.assemblytics
# # delete extra output files :
# ref_qry.delta.assemblytics.Assemblytics_results.zip
# ref_qry.delta.assemblytics.coords.csv
# ref_qry.delta.assemblytics.coords.query.genome
# ref_qry.delta.assemblytics.coords.ref.genome
# ref_qry.delta.assemblytics.coords.tab
# ref_qry.delta.assemblytics.info.csv
# ref_qry.delta.assemblytics.oriented_coords.csv
# ref_qry.delta.assemblytics.query.index
# ref_qry.delta.assemblytics.ref.index
# ref_qry.delta.assemblytics.variant_preview.txt
# ref_qry.delta.assemblytics.variants_between_alignments.bed
# ref_qry.delta.assemblytics.variants_within_alignments.bed
# module purge

#####################
if ($use_sbatch  == 1) {print "\n\nUsing sbatch to parallelize\n\n";}

### now construct the command for each directory (=sample) specified on the command line
foreach my $file (@ARGV) {
    if (!-e $file) {
        die "\n\nterminating - file $file does not exist\n\n";
    }
    print "\n### file $file\n";
    my $outprefix = $file . "_Assemblytics";
    if (-e $outprefix) {
        print "    skipping it - outprefix $outprefix exists\n";
        next;
    }
    my $logFile = "$outprefix.log.txt";
    my $logFile2 = "$outprefix.log2.txt";
    my $shellScriptFile = "$outprefix.sh";
    print "    creating shell script $shellScriptFile\n";
    open (SH, "> $shellScriptFile");
    print SH "#!/bin/bash\n";
    print SH "source /app/lmod/lmod/init/profile\n";
    print SH "module purge\n"; 
    print SH "module load fhR/4.0.2-foss-2019b 2>&1 >> $logFile\n";
    print SH "module load Python/3.7.4-foss-2019b-fh1 2>&1 >> $logFile\n";
    print SH "Assemblytics $file $outprefix $unique_anchor_length $min_variant_size $max_variant_size 2>&1 >> $logFile\n";
    
    # remove extra output files
    print SH "rm $outprefix.Assemblytics_results.zip\n";
    print SH "rm $outprefix.coords.csv\n";
    print SH "rm $outprefix.coords.query.genome\n";
    print SH "rm $outprefix.coords.ref.genome\n";
    print SH "rm $outprefix.coords.tab\n";
    print SH "rm $outprefix.info.csv\n";
    print SH "rm $outprefix.oriented_coords.csv\n";
    print SH "rm $outprefix.query.index\n";
    print SH "rm $outprefix.ref.index\n";
    print SH "rm $outprefix.variant_preview.txt\n";
    print SH "rm $outprefix.variants_between_alignments.bed\n";
    print SH "rm $outprefix.variants_within_alignments.bed\n";
    
    # move the remaining output files to a folder
    print SH "if [ ! -e $outprefix ]\n";
    print SH "then\n";
    print SH "    echo making $outprefix\n";
    print SH "    mkdir $outprefix\n";
    print SH "fi\n";
    print SH "mv $outprefix.* $outprefix\n";
    print SH "module purge\n";
    
    my $command;
    if ($use_sbatch == 1) {
        $command = "sbatch -t $walltime --job-name=assemblytics_$file --cpus-per-task=$numThreads --wrap=\"bash ./$shellScriptFile 2>&1 > $logFile2\"";
    } else {
        $command = "bash ./$shellScriptFile 2>&1 >> $logFile2";
    }
    print "    command:\n        $command\n\n";
    if ($debug == 0) { system($command); }
    next;
}

if ($use_sbatch == 1) {
    print "\n\nSet all jobs going - use sq command to monitor whether there are still any assemblytics commands running\n\n";
}

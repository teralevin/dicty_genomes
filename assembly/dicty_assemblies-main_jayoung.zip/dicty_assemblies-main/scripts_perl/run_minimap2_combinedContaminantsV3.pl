#!/usr/bin/perl

use warnings;
use strict;
use Getopt::Long;

### get parameters

## I perhaps should have set -x map-ont to tell it I'm mapping Nanopore vs reference mapping but luckily, the default setting is the same as map-ont

# defaults
my $genome = "/fh/fast/malik_h/user/jayoung/forOtherPeople/forTera/dicty_assemblies/data/resources/combine_contaminants/combined_contaminants_v3.fa";
my $outdir = ".";

my $use_sbatch = 1;
my $numThreads = 4;
my $walltime = "3-0";
my $debug = 0;

### 
GetOptions("genome=s"      => \$genome, 
           "out=s"         => \$outdir, 
           "t=i"           => \$numThreads,           # '--t 4' to use 4 threads
           "sbatch=i"      => \$use_sbatch,
           "wall=s"        => \$walltime,             # '--wall 0-6' to specify 6 hrs
           "debug"         => \$debug                 # '--debug' to just test
           ) or die "\n\nterminating - unknown option(s) specified on command line\n\n"; 


#####################
if ($use_sbatch eq "yes") {print "\n\nUsing sbatch to parallelize\n\n";}

if (!-e $genome) {
    die "\n\nterminating - genome file $genome does not exist\n\n";
}

### now construct the command for each fastq file specified on the command line
foreach my $file (@ARGV) {
    print "file $file\n";
    ## figure out output file name
    my $fileNameWithoutDirName = $file;
    if ($fileNameWithoutDirName =~ m/\//) {
        $fileNameWithoutDirName = (split /\//, $fileNameWithoutDirName)[-1];
    }
    my $outfileStem = $fileNameWithoutDirName;
    $outfileStem = "$outdir/$outfileStem";
    $outfileStem =~ s/\.gz$//;
    $outfileStem =~ s/\.fastq$//;
    $outfileStem =~ s/\.fq$//;
    
    my $shellScript = "$outfileStem.minimap2.sh";
    my $outfile = "$outfileStem.minimap2.bam";
    my $logfile = "$outfileStem.log.txt";
    
    ## check whether outfile exists
    if (-e $outfile) {
        print "\nskipping file $file - outfile $outfile already exists\n\n";
        next;
    }
    
    ## get date so I can set up a unique tmp dir name
    my $date = `date -Ins`; chomp $date;
    $date =~ s/,/_/g; $date =~ s/:/_/g; 
    my $tmpDir = "\$\{DELETE30\}/malik_h/$fileNameWithoutDirName" . "_$date";
    
    ### construct the command:
    open (SH, "> $shellScript");
    print SH "#!/bin/bash\n";
    print SH "source /app/lmod/lmod/init/profile\n";
    print SH "module load minimap2/2.17-GCC-8.3.0\n";
    
    print SH "echo 'minimap2'\n";
    print SH "minimap2 -t 4 -a $genome $file > $outfileStem.minimap2.unsorted.sam\n";
    print SH "module purge\n";
    
    print SH "# convert sam to bam, then sort, index flagstat\n";
    print SH "module load SAMtools/1.11-GCC-10.2.0\n";
    print SH "echo 'sam to bam'\n";
    print SH "samtools view -@ 4 -Sb $outfileStem.minimap2.unsorted.sam > $outfileStem.minimap2.unsorted.bam\n";
    print SH "echo 'sort bam'\n";
    print SH "samtools sort -@ 4 -o $outfileStem.minimap2.bam -O bam -T $tmpDir $outfileStem.minimap2.unsorted.bam\n";
    print SH "echo 'index sorted bam'\n";
    print SH "samtools index -@ 4 $outfileStem.minimap2.bam\n";
    print SH "echo 'flagstat'\n";
    print SH "samtools flagstat -@ 4 $outfileStem.minimap2.bam > $outfileStem.minimap2.bam.flagstats\n";
    print SH "module purge\n";

    print SH "# remove intermediate files:\n";
    print SH "rm $outfileStem.minimap2.unsorted.bam $outfileStem.minimap2.unsorted.sam\n";
    
    close SH;
    
    my $runCommand = "bash $shellScript > $logfile 2>&1";
    if ($use_sbatch == 1) {
        $runCommand = "sbatch --job-name=minimap2 -t $walltime --cpus-per-task=$numThreads --wrap=\"$runCommand\"";
    } 
    print "command:\n    $runCommand\n\n";
    if ($debug == 0) {system($runCommand);}
}

if ($use_sbatch == 1) {
    print "\n\nSet all jobs going - use sq command to monitor whether there are still any minimap2 commands running\n\n";
}




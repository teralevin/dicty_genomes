#!/usr/bin/perl
use warnings;
use strict;
use Cwd;
use Getopt::Long;

# https://mummer4.github.io/manual/manual.html

##### for each masked assembly, make a new dir for promer output, and compare to the masked reference genome

# https://mummer4.github.io/manual/manual.html
# promer --prefix=ref_qry --maxmatch ref.fasta.masked qry.fasta.masked


# show-coords -rcl ref_qry.delta > ref_qry.coords
# fixMUMmerCoordsFile.pl ref_qry.coords
# show-aligns ref_qry.delta refname qryname > ref_qry.aligns
# show-tiling ref_qry.delta > ref_qry.tiling
#Where refname and qryname are the FastA IDs of two sequences. The show-aligns step will have to be repeated for every combination of sequences that the user wishes to analyze. If mapping the draft sequences to each of their repeat locations is not required, the delta-filter program can quickly select the optimal placement of each draft sequence to the reference using the following:
#  delta-filter -q ref_qry.delta > ref_qry.filter
# The newly created delta file ref_qry.filter can then be substituted for the original in the above procedures in order to generate slimmed down versions of the output.

## have to use the old executable, as I'm getting this error: https://github.com/mummer4/mummer/issues/55
my $promerExe = "/home/jayoung/malik_lab_shared/linux_gizmo/bin/MUMmer3.23/promer";

my $projectHome = "/fh/fast/malik_h/user/jayoung/forOtherPeople/forTera/dicty_assemblies";

my $fixCoordsScript = "$projectHome/scripts_perl/fixMUMmerCoordsFile.pl";

my $referenceGenome = "$projectHome/data/resources/Dictyostelium_discoideum/dicty_chromosomal.names.fa_RepeatMasker/dicty_chromosomal.names.fa.masked";

my $outputDirExtension = "_promer";
my $outputPrefix = "ref_qry";

# -maxmatch: Compute all maximal matches regardless of their uniqueness
# -l: Minimum match length (default 20)
# -c: Minimum cluster length
my $promerOptions = "--maxmatch"; # Use all anchor matches regardless of their uniqueness

my $deltaFilterOptions = "-m";  ### -m  Many-to-many alignment allowing for rearrangements (union of -r and -q alignments)
my $showCoordsOptions = "-rcld";  ### show-coords: view alignments summary
# -r: sort by ref ID and coord, 
# -c -l and -d = include percent IDs, seq length, strand in output
# -o Annotate maximal alignments between two sequences, i.e. overlaps between reference and query sequences


my $numThreads = 1;
my $use_sbatch = 1;
my $walltime = "1-0";
my $debug = 0;

GetOptions("home=s"               => \$projectHome,
           "script=s"             => \$fixCoordsScript, 
           "ref=s"                => \$referenceGenome, 
           "outDirSuffix=s"       => \$outputDirExtension, 
           "outFilePrefix=s"      => \$outputPrefix, 
           "nucmerOptions=s"      => \$promerOptions, 
           "deltaFilterOptions=s" => \$deltaFilterOptions, 
           "showCoordsOptions=s"  => \$showCoordsOptions, 
          # "t=i"                  => \$numThreads, ## promer cannot multithread (I think) 
           "sbatch=i"             => \$use_sbatch,
           "wall=s"               => \$walltime,      
           "debug"                => \$debug  # '--debug' to just test, not actually run
           ) or die "\n\nterminating - unknown option(s) specified on command line\n\n"; 



#####################

if ($use_sbatch == 1) {print "\n\nUsing sbatch to parallelize\n\n";}
my $cwd = cwd();

if (!-e $projectHome) {
    die "\n\nterminating - projectHome does not exist (perhaps use -home option): $projectHome\n\n";
}

if (!-e $fixCoordsScript) {
    die "\n\nterminating - fixCoordsScript does not exist (perhaps use -script option): $fixCoordsScript\n\n";
}

### check ref genome and set up link
if (!-e $referenceGenome) {
    die "\n\nterminating - ref genome does not exist (perhaps use -ref option): $referenceGenome\n\n";
}
my $referenceGenomeLocalLink = $referenceGenome;
if ($referenceGenomeLocalLink =~ m/\//) {
    $referenceGenomeLocalLink = (split /\//, $referenceGenomeLocalLink)[-1];
}


foreach my $file (@ARGV) {
    if (!-e $file) {
        die "\n\nterminating - file $file does not exist\n\n";
    }
    my $outDir = $file.$outputDirExtension;
    if (-e $outDir) {
        print "skipping $file - outfile $outDir exists already\n\n";
        next;
    }
    my $fileWithoutDirName = $file;
    if ($fileWithoutDirName =~ m/\//) {
        $fileWithoutDirName = (split /\//, $fileWithoutDirName)[-1];
    }
    my $actualInputFile = $fileWithoutDirName;
    mkdir $outDir;
    chdir $outDir;    
    ## set up links to assembly files
    system("ln -s $referenceGenome .");
    system("ln -s ../$actualInputFile .");
    ## update actual input file
    if ($actualInputFile =~ m/\//) {
        $actualInputFile = (split /\//, $actualInputFile)[-1];
    }

    ## build up the command
    my $command = "$promerExe $promerOptions --prefix=$outputPrefix $referenceGenomeLocalLink $actualInputFile";
    $command .= " ; delta-filter $deltaFilterOptions $outputPrefix.delta > $outputPrefix.filter.delta";
    $command .= " ; show-coords $showCoordsOptions $outputPrefix.delta > $outputPrefix.coords";
    $command .= " ; $projectHome/scripts_perl/fixMUMmerCoordsFile.pl -verbose=0 $outputPrefix.coords";
    $command .= " ; show-tiling $outputPrefix.delta > $outputPrefix.tiling";
    $command .= " ; show-coords $showCoordsOptions $outputPrefix.filter.delta > $outputPrefix.filter.coords";
    $command .= " ; $projectHome/scripts_perl/fixMUMmerCoordsFile.pl -verbose=0 $outputPrefix.filter.coords";
    $command .= " ; show-tiling $outputPrefix.filter.delta > $outputPrefix.filter.tiling";
    
    my $logFile = $outputPrefix.".promerCommands.log.txt";
    open (OUT, "> $logFile");
    print "##### Running promer to compare reference $referenceGenomeLocalLink with query $actualInputFile in dir $outDir\n";
    print OUT "##### Running promer to compare reference $referenceGenomeLocalLink with query $actualInputFile in dir $outDir\n";
    my $tidyCommand = $command;
    $tidyCommand =~ s/\s\;\s/\n\n/g;
    print "    Command:\n\n$tidyCommand\n\n";
    print OUT "    Command:\n\n$tidyCommand\n\n";
    close OUT;
    if ($use_sbatch == 1) {
        my $time = "";
        if ($walltime ne "default") { $time = "-t $walltime"; }
        $command = "sbatch --cpus-per-task=$numThreads --job-name=promer $time --wrap=\"$command\"";
    }
    system($command);
    chdir $cwd;
}

if ($use_sbatch == 1) {
    print "\n\nSet all jobs going - use sq command to monitor whether there are still any promer commands running\n\n";
}


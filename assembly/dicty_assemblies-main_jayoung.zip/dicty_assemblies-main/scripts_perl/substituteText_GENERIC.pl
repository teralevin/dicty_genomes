#!/usr/bin/perl
use warnings;
use strict;
use Getopt::Long;

my $prefix = "";
my $suffix = "";
my $find = "";
my $replace = "";
my $outsuffix = "changed.txt";
my $numLinesToPrint = 1;

GetOptions("prefix=s"      => \$prefix,
           "min=s"         => \$suffix,
           "find=s"        => \$find,
           "replace=s"     => \$replace,
           "outsuffix=s"   => \$outsuffix,
           "print=i"       => \$numLinesToPrint
           ) or die "\n\nterminating - unknown option(s) specified on command line\n\n"; 


##########

if (($replace ne "") & ($find eq "")) {
    die "\n\nTerminating - you specified a 'replace' string but not a 'find' string - that doesn't make sense\n\n";
}
if (($prefix eq "") & ($suffix eq "") & ($find eq "")) {
    die "\n\nTerminating - you need to specify one or more of these options: prefix/suffix/find (and possibly replace)\n\n";
}

if (@ARGV==0) {
    die "\n\nTerminating - please specify fasta file(s) to work on\n\n";
}

print "\nChanging text as follows:\n";
if ($prefix ne "") { print "    adding prefix to each line: $prefix\n"; }
if ($suffix ne "") { print "    adding suffix to each line: $suffix\n"; }
if ($find ne "") { print "    finding $find and replacing with '$replace'\n"; }

foreach my $file (@ARGV){
    print "\n### Working on file $file\n\n";
    if (!-e $file) { die "\n\nTerminating - file $file does not exist\n\n"; }
    my $outfile = $file; 
    $outfile =~ s/\.fa$//; $outfile =~ s/\.fasta$//; $outfile =~ s/\.gff$//;
    $outfile .= $outsuffix;
    if (-e $outfile) { die "\n\nTerminating - outfile exists already: $outfile\n\n"; }
    open (IN, "< $file");
    open (OUT, "> $outfile");
    my $numLinesPrinted = 0;
    while (<IN>) {
        my $line = $_; chomp $line;
        my $newline = $line;
        if ($prefix ne "") { $newline = $prefix . $newline; }
        if ($suffix ne "") { $newline = $newline . $suffix; }
        if ($find ne "") { $newline =~ s/$find/$replace/g; }
        if ($numLinesPrinted <= $numLinesToPrint) {
            print "\n    Changing old line:\n$line\n\n";
            print "    to new line:\n$newline\n\n";
        }
        print OUT "$newline\n";
        $numLinesPrinted++
    }
    close OUT;
    close IN;
}

#!/usr/bin/perl

use warnings;
use strict;

### from each fasta file, removes any section at the end that has fasta format sequences
## it probably won't work for all gffs, as there may not be a consistent way to denote where the sequence section begins.

foreach my $file (@ARGV) {
    if (!-e $file) { die "\n\nterminating - file $file does not exist";} 
    my $out = $file; $out =~ s/\.gff$//;$out =~ s/\.gff3$//;
    if($file =~ m/gff3/) {
        $out .= ".noSeq.gff3";
    } else {
        $out .= ".noSeq.gff";
    }
    print "working on file $file\n";
    open (IN, "< $file");
    open (OUT, "> $out");
    while (<IN>) {
        my $line = $_; 
        if ($line =~ m/^##FASTA/) { last; } ## MAKER gffs have fasta section at the end, starting like this. Same for Geneious gff export.
        print OUT $line;
    }
    close OUT;
    close IN;
}


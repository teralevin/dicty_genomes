#!/usr/bin/perl

use warnings;
use strict;

### combines multiple GFF files into one.
### for header rows (begin #), always ignore sequence-region rows, and keep the other rows only for the first file.
### some gff files (that I downloaded from flybase, see /fh/fast/malik_h/grp/public_databases/UCSC/fly_Apr2006/misc_tracks/flyBaseGeneGFFsFromFlyBase) seem to have a fasta section to them, that comes after a line that has only "###" - ignore this section. There's nothing after that section
### same issue with the dictybase gffs, except that the line
my $outfile = "combinedFiles.gff";

open (OUT, "> $outfile");
my $firstFile = "yes";
foreach my $file (@ARGV) {
    if (!-e $file) { die "\n\nterminating - file $file does not exist";} 
    print "working on file $file\n";
    open (IN, "< $file");
    while (<IN>) {
        my $line = $_; 
        if ($line =~ m/^###/) { last; } ## flybase gffs have fasta section at the end, starting like this
        if ($line =~ m/^##FASTA/) { last; } ## dictybase gffs have fasta section at the end, starting like this
        if ($line !~ m/^#/) { print OUT $line; next; }
        if ($line =~ m/^##sequence-region/) { next; }
        if ($firstFile eq "yes") { print OUT $line; }
    }
    $firstFile = "no";
    close IN;
}
close OUT;


#!/usr/bin/perl
use warnings;
use strict;
use Getopt::Long;

###### runs KAD on each file specified on the command line, and removes some of the larger output files

## usage: runKAD.pl --reads=reads1.fq.gz,reads2.fq.gz [other options] assembly1.fa assembly2.fa

my $readsString = "";
my $outdirSuffix = "KAD";
my $outdirOption = "";

my $use_sbatch = 1;
my $numThreads = 12;
my $walltime = "3-0";
my $debug = 0;

GetOptions("reads=s"       => \$readsString,
           "outdir=s"      => \$outdirOption,
           "outsuffix=s"   => \$outdirSuffix,
           "t=i"           => \$numThreads,           # '--t 4' to use 4 threads
           "sbatch=i"      => \$use_sbatch,
           "wall=s"        => \$walltime,             # '--wall 0-6' to specify 6 hrs
           "debug"         => \$debug                 # '--debug' to just test
           ) or die "\n\nterminating - unknown option(s) specified on command line\n\n"; 

my $KADscript = "/fh/fast/malik_h/user/jayoung/forOtherPeople/forTera/dicty_assemblies/installations/KAD/KAD/KADprofile.pl";

# module purge
# module load fhR/4.0.2-foss-2019b
# module load Pandoc/2.10
# export R_LIBS_USER=/home/jayoung/malik_lab_shared/linux_gizmo/R_packages/v_fh_4.0.2-foss-2019b
# perl ~/dicty_assemblies/installations/KAD/KAD/KADprofile.pl --threads 4 --asm assembly.fasta --read ../../TL1_KGL29A_S322_R1.nonKleb2.fastq.gz --read ../../TL1_KGL29A_S322_R2.nonKleb2.fastq.gz
# module purge


#####################
if ($use_sbatch  == 1) {print "\n\nUsing sbatch to parallelize\n\n";}
if (!-e $KADscript) {
    die "\n\nterminating - KAD script $KADscript does not exist\n\n";
}
my @assemblies = @ARGV;
my $numAssemblies = @assemblies;
if (@ARGV == 0) {
    die "\n\nterminating - you must specify one or more assembly files on the command line\n\n";
}
if ($readsString eq "") {
    die "\n\nterminating - you must specify the reads using --reads (use commas if there are several files)\n\n";
}

## construct reads option
my @reads = split /,/, $readsString;
my $readsKADstring = "";
foreach my $readsFile (@reads) {
    if (!-e $readsFile) {
        die "\n\nterminating - reads file $readsFile does not exist\n\n";
    }
    $readsKADstring .= " --read $readsFile";
}

## construct asm option (assemblies)
my $assembliesKADstring = "";
foreach my $assemblyFile (@assemblies) {
    if (!-e $assemblyFile) {
        die "\n\nterminating - assembly file $assemblyFile does not exist\n\n";
    }
    $assembliesKADstring .= " --asm $assemblyFile";
}

## figure out output dir
my $outdir;
if ($numAssemblies > 1) { # for multiple assemblies we don't want to use the assembly name as part of the outdir
    if ($outdirOption ne "") {
        $outdir = $outdirOption;
    } else {
        $outdir = "allAssemblies_" . $outdirSuffix;
    }
} else { ## if there's only one assembly, we tag the suffix on to the assembly name
    $outdir = $assemblies[0] . "_" . $outdirSuffix;
}
if (-e $outdir) {
    die "\n\nTerminating - outdir $outdir exists\n";
}

my $logFile = $outdir . ".log.txt";
my $shellScript = $outdir . ".run.sh";
print "    creating shell script $shellScript\n";
open (SH, "> $shellScript");
print SH "#!/bin/bash\n";
print SH "source /app/lmod/lmod/init/profile\n";
print SH "module purge\n";
print SH "module load fhR/4.0.2-foss-2019b 2>&1 >> $logFile\n";
print SH "module load Pandoc/2.10 2>&1 >> $logFile\n";
print SH "export R_LIBS_USER=/home/jayoung/malik_lab_shared/linux_gizmo/R_packages/v_fh_4.0.2-foss-2019b\n";
print SH "perl $KADscript --prefix $outdir --threads $numThreads $assembliesKADstring $readsKADstring 2>&1 >> $logFile\n";
print SH "module purge\n";
# remove the larger output files
print SH "rm $outdir/$outdir"."_0_reads.kmer.table.txt\n";
print SH "rm $outdir/$outdir"."_1_*.kmer.table.txt\n";
print SH "rm $outdir/$outdir"."_2_merge.kmer.table.txt\n";
print SH "rm $outdir/$outdir"."_4_kad.txt\n";
print SH "mv $outdir"."_KADrun.log $outdir\n";
print SH "mv $shellScript $outdir\n";
print SH "mv $logFile $outdir\n";

my $command;
if ($use_sbatch == 1) {
    $command = "sbatch -t $walltime --job-name=KAD --cpus-per-task=$numThreads --wrap=\"bash ./$shellScript 2>&1 >> $logFile\"";
} else {
    $command = "bash ./$shellScript 2>&1 >> $logFile";
}
print "    command:\n        $command\n\n";
if ($debug == 0) { system($command); }


if ($use_sbatch == 1) {
    print "\n\nSet all jobs going - use sq command to monitor whether there are still any KAD commands running\n\n";
}

#!/usr/bin/perl
use warnings;
use strict;
use Getopt::Long;

###### MUMMER's coords output file format is horrible. Put it in a normal tab-delimited format.  This works when show-coords was run like this:
## show-coords -r -c -l -d nucmerMICvsMAC.delta.filtered > nucmerMICvsMAC.coords.filtered


my $verbose = 1;
GetOptions("verbose=i"     => \$verbose
           ) or die "\n\nterminating - unknown option(s) specified on command line\n\n"; 


foreach my $file (@ARGV) {
    if (!-e $file) { 
        print "\nskipping input file $file - it does not exist\n\n";
        next;
    } 
    if ($verbose == 1) { print "\nfile $file\n\n"; }
    open (IN, "< $file");
    open (OUT, "> $file.fix");
    my @lines = (<IN>);
    for (my $i=1;$i<=3;$i++) {
        my $tempLine = shift @lines;
        if ($verbose == 1) { print "    $i getting rid of line $tempLine"; }
    }
    #shift @lines; shift @lines; shift @lines;
    
    my $header = shift @lines; chomp $header;
    if ($verbose == 1) { print "  got header $header\n"; }
    $header =~ s/\|//g; 
    if ($header =~ m/\[SUB\]/) {
        $header =~ s/\[SUB\]/SUB_ref\tSUB_query/;
    }
    $header =~ s/[\[\]]//g;
    my @h = split /\s\s+/, $header; shift @h;
    my $newHeader = join "\t", @h;
    $newHeader .= "\tRef\tQuery\n";
    $newHeader =~ s/\%/PCT/; $newHeader =~ s/ /_/g;
    print OUT $newHeader;
    #shift @lines;
    my $tempLine = shift @lines; 
    if ($verbose == 1) { print "    getting rid of line $tempLine\n\n"; }
    foreach my $line (@lines) {
        chomp $line;
        $line =~ s/\|//g; $line =~ s/[\[\]]//g;
        my @f = split /\s+|\t/, $line; shift @f;
        my $newline = join "\t", @f;
        print OUT "$newline\n";
    }
    close IN;
    close OUT;
}


#!/usr/bin/perl
use warnings;
use strict;
use Getopt::Long;
use Cwd;

#usage: runRepeatMasker.pl (repeatmasker args, if any) (-species species_if_not_human) -files file1.fasta file2.fasta etc

# cd ~/FH_fast_storage/temp/testRepeatMasker
# ~/dicty_assemblies/scripts_perl/runRepeatMasker.pl H_GS165I04start.fasta

# ~/dicty_assemblies/scripts_perl/runRepeatMasker.pl -outsuffix=useLibs H_GS165I04start.fasta

# I tested use of -dir option in RM but it didn't seem to work well

my $species = "";
my $otherOptions = "";
my $outdirSuffix = "_RepeatMasker";

my $RMpath = "/home/jayoung/malik_lab_shared/lib/RepeatMasker2015_Oct29_linux_64/RepeatMasker/RepeatMasker";

my $jobname = "RepMask";
my $numThreads = 4;
my $use_sbatch = 1;
my $walltime = "0-4";
my $debug = 0;

GetOptions("species=s"     => \$species,
           "options=s"     => \$otherOptions,
           "outsuffix=s"   => \$outdirSuffix,
           "job=s"         => \$jobname,
           "t=i"           => \$numThreads,     # '--t 4' to use 4 threads           
           "sbatch=i"      => \$use_sbatch,
           "wall=s"        => \$walltime,       # '--wall 0-6' to specify 6 hrs
           "debug"         => \$debug           # '--debug' to just test, not actually run
           ) or die "\n\nterminating - unknown option(s) specified on command line\n\n"; 


###########

my $cwd = cwd();

if ($use_sbatch == 1) {print "\n\nUsing sbatch to parallelize\n\n";}
my @files = @ARGV;

if (@files == 0) {
    print "\n\nterminating - specify one or more files to mask\n\n";
    usage();
}

if (!-e $RMpath) {
    print "\n\nterminating - the RepeatMasker path specified in the script does not exist: $RMpath\n\n";
    usage();
}

foreach my $file (@files) {
    if (!-e $file) {
        print "\n\nterminating - file $file does not exist\n\n";
        usage();
    }
    
    my $fileStem = $file; $fileStem =~ s/\.fasta$//; $fileStem =~ s/\.fa$//;
    
    my $outDir = $file . $outdirSuffix;
    if (!-e $outDir) {mkdir $outDir;}
    if (!-e "$outDir/$file") { system("ln -s $cwd/$file $outDir/$file"); }
    
    chdir $outDir;
    my $finalOutfile = "$file.masked";
    my $logFile = "$fileStem.runRepeatMasker.log.txt";
    
    if (-e $finalOutfile) {
        print "skipping file $file - output file $finalOutfile exists already\n"; chdir $cwd; next;
    }
    if (-e $logFile) {
        print "skipping file $file - log file $logFile exists already\n"; chdir $cwd; next;
    }
    print "\nRepeatMasking file $file\n";    
    
    my $RMcommand = "$RMpath -pa $numThreads $otherOptions";
    if ($species ne "") {$RMcommand .= " -species $species"; }
    $RMcommand .= " $file";
    $RMcommand .= " 2>&1 >> $logFile";
    
    open (LOG, "> $logFile");
    print LOG "\nRepeatMasker command is:\n$RMcommand\n\n\n";
    close LOG;
    #my $shellScript = "$outDir/$fileStem.runRepeatMasker.sh";
    #open (SH, "> $shellScript");
    #print SH "#!/bin/bash\n";
    #print SH "echo 'Running command: $RMcommand' >> $logFile\n";
    #print SH "$RMcommand 2>&1 >> $logFile\n";
    #close SH;
    
    my $command = $RMcommand;
    if ($use_sbatch == 1) {
        $command = "sbatch --cpus-per-task=$numThreads -t $walltime --job-name=$jobname --wrap=\"$RMcommand\"";
    } 
    print "command $command\n\n";
    if ($debug == 0) { system($command); }
    chdir $cwd;
}

if ($use_sbatch == 1) {
    print "\n\nSet all jobs going - use sq command to monitor whether there are still any $jobname commands running\n\n";
}

#------------
sub usage {
    die "\nusage : runRepeatMasker.pl\n    [--species=\"Mus musculus\"\n    --options=\"any other repeatMasker options\"\n    --outsuffix=\"_outputGoesInDirWithThisSuffix\"]\n        file(s).fasta\n\n";
}

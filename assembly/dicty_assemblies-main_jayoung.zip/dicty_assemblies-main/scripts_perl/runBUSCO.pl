#!/usr/bin/perl

use warnings;
use strict;
use Getopt::Long;

####### runBUSCO.pl assembly.fa

## in 2021 I updated our BUSCO installation (v4.1.2). See old/runBUSCO.pl for a version of the script that'll work with the much older BUSCO. Command-line is different now, and there are other dependencies

### specify lineage: this shows the options: "busco --list-datasets"
my $lineage = "auto";   # busco will autodetect lineage- takes longer
#my $lineage = "diptera_odb10";
#my $lineage = "saccharomycetes_odb10";
#my $lineage = "eukaryota_odb10";   ### use this for Dicty genomes

my $mode = "genome"; # could also be transcriptome or proteins


my $outdirSuffix = "BUSCO";

my $buscoOptions = "";

## by default, run in offline mode. See below for how download_path is specified
my $offline = 1;

my $use_sbatch = 1;
my $numThreads = 4;
my $walltime = "3-0";
my $debug = 0;

GetOptions("lineage=s"     => \$lineage,
           "mode=s"        => \$mode,
           "outsuffix=s"   => \$outdirSuffix,
           "options=s"     => \$buscoOptions,
           "offline=s"     => \$offline,
           "t=i"           => \$numThreads,           # '--t 4' to use 4 threads
           "sbatch=i"      => \$use_sbatch,
           "wall=s"        => \$walltime,             # '--wall 0-6' to specify 6 hrs
           "debug"         => \$debug                 # '--debug' to just test
           ) or die "\n\nterminating - unknown option(s) specified on command line\n\n"; 


#### busco's config file:
## is called /fh/fast/malik_h/grp/malik_lab_shared/lib/busco/config.ini
## it is read because I have this env set:
# BUSCO_CONFIG_FILE=/fh/fast/malik_h/grp/malik_lab_shared/lib/busco/config.ini
## and specifies these options 
# download_path = /fh/fast/malik_h/grp/malik_lab_shared/lib/busco/busco_downloads
# offline=True
# [tblastn]
# path = /app/software/BLAST+/2.10.1-gompi-2020a/bin/
# command = tblastn
# [makeblastdb]
# path = /app/software/BLAST+/2.10.1-gompi-2020a/bin/
# command = makeblastdb


#####################
if ($use_sbatch == 1) {print "\n\nUsing sbatch to parallelize\n\n";}

foreach my $file (@ARGV) {
    if (!-e $file) {
        die "\n\nterminating - assembly file $file does not exist\n\n";
    }
    my $outfile = $file . "_" . $outdirSuffix;
    ## BUSCO doesn't like output file to be a path
    if ($outfile =~ m/\//) {
        $outfile = (split /\//, $outfile)[-1];
    }
    my $logfile = "$file.$outdirSuffix.log.txt";
    if (-e $logfile) {
        print "skipping $file - logfile $logfile exists already\n\n"; 
        next;
    }
    open (LOG, "> $logfile");
    
    my $shellScript = "$file.$outdirSuffix.runScript.sh";
    open (SH, "> $shellScript");
    print SH "#!/bin/bash\n";
    print SH "source /app/lmod/lmod/init/profile\n";
    print SH "module purge\n";
    print SH "module load Biopython/1.77-foss-2020a-Python-3.8.2\n";
    print SH "module load Java/1.8.0_181\n";
    print SH "module load BLAST+/2.10.1-gompi-2020a\n"; ## because busco won't do multithreading with any other version (it's really complaining that it doesn't want an OLDER version because of multithreading issues, but it also won't try multithreading on a newer version)
    print SH "busco";
    if ($offline) { print SH " --offline"; }
    print SH " -i $file -c $numThreads -m $mode -o $outfile $buscoOptions";
    if ($lineage ne "auto") { print SH " -l $lineage"; }
    print SH " 2>&1 >> $logfile\n";
    print SH "module purge\n";
    close SH;
    
    my $command;
    if ($use_sbatch == 1) {
        $command = "sbatch --job-name=BUSCO -t $walltime --cpus-per-task=$numThreads --wrap=\"bash ./$shellScript 2>&1 >> $logfile\"";
    } else {
        $command = "bash ./$shellScript 2>&1 >> $logfile";
    }
    print "command $command\n\n";
    print LOG "running command:\n$command\n\n";
    close LOG;
    if ($debug == 0) { system($command); }
}

if (($use_sbatch == 1) & ($debug == 0)) {
    print "\n\nSet all jobs going - use sq command to monitor whether there are still any BUSCO commands running\n\n";
}


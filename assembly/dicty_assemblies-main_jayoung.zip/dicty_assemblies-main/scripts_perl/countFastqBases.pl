#!/usr/bin/perl

use warnings;
use strict;
use File::Spec;

##### count total num bases in each fastq file specified on command line
##### uses command line:
# zcat test.fastq.gz | paste - - - - | cut -f 2 | tr -d '\n' | wc -c 
# got this from here: https://bioinformatics.stackexchange.com/questions/14272/how-to-measure-the-total-size-of-a-fastq-file-in-base-pairs

open (OUT, "> basepaircounts.txt");
print OUT "File\tDir\tNumBases\n";
my $total = 0;
foreach my $file (@ARGV) {
    if (!-e $file) {
        die "\n\nterminating - cannot open file $file\n\n";
    }
    print "working on file $file\n";
    my ($volume,$dir,$shortfile) = File::Spec->splitpath( $file );
    $dir =~ s/\/$//;
    if ($dir eq "") {$dir = ".";}
    my $catCommand = "cat";
    if ($file =~ m/gz$|gzip$/) { $catCommand = "zcat"; } 
    if ($file =~ m/bz2/) { $catCommand = "bzcat"; }
    my $command = "$catCommand $file | paste - - - - | cut -f 2 | tr -d '\n' | wc -c";
    my $numBP = `$command`; chomp $numBP;
    print OUT "$shortfile\t$dir\t$numBP\n";    
    $total += $numBP;
}
print OUT "Total\tAllDirs\t$total\n";
close OUT;

#!/usr/bin/perl

use warnings;
use strict;
use Getopt::Long;

### I commonly need to edit this script to extract the sample name from the fastq.gz file names

### this is the newer version of bwa, mem: "BWA-MEM is the latest version of bwa, is generally recommended for high-quality queries as it is faster and more accurate."

### I run this directly, not via batch_bwa_hyrax_MASTERscript.pl

#### http://bio-bwa.sourceforge.net
# BWA is a software package for mapping low-divergent sequences against a large reference genome, such as the human genome. It consists of three algorithms: BWA-backtrack, BWA-SW and BWA-MEM. The first algorithm (backtrack) is designed for Illumina sequence reads up to 100bp, while the rest two for longer sequences ranged from 70bp to 1Mbp. BWA-MEM and BWA-SW share similar features such as long-read support and split alignment, but BWA-MEM, which is the latest, is generally recommended for high-quality queries as it is faster and more accurate. BWA-MEM also has better performance than BWA-backtrack for 70-100bp Illumina reads.


### get parameters

# defaults
my $genome = "/fh/fast/malik_h/user/jayoung/forOtherPeople/forTera/dicty_assemblies/data/resources/klebsiella/CP052309acc.txt.fasta_indexForBWA/CP052309acc.txt.fasta";
my $outdir = ".";
my $paired = 1;
my $index = 1; # index bam file as well
my $runFlagstat = 1;

my $use_sbatch = 1;
my $numThreads = 4;
my $walltime = "3-0";
my $debug = 0;

### 
GetOptions("genome=s"      => \$genome, 
           "out=s"         => \$outdir, 
           "pair=i"        => \$paired, 
           "index=i"       => \$index, 
           "flagstat=i"    => \$runFlagstat, 
           "t=i"           => \$numThreads,           # '--t 4' to use 4 threads
           "sbatch=i"      => \$use_sbatch,
           "wall=s"        => \$walltime,             # '--wall 0-6' to specify 6 hrs
           "debug"         => \$debug                 # '--debug' to just test
           ) or die "\n\nterminating - unknown option(s) specified on command line\n\n"; 


### example command: bwa mem ref.fa read1.fq.gz read2.fq.gz > aln-pe.sam

#####################
if ($use_sbatch eq "yes") {print "\n\nUsing sbatch to parallelize\n\n";}

if (!-e $genome) {
    die "\n\nterminating - genome file $genome does not exist\n\n";
}

### now construct the command for each fastq file specified on the command line
foreach my $file (@ARGV) {
    print "file $file\n";
    ## figure out output file name
    my $fileNameWithoutDirName = $file;
    if ($fileNameWithoutDirName =~ m/\//) {
        $fileNameWithoutDirName = (split /\//, $fileNameWithoutDirName)[-1];
    }
    my $outfile = $fileNameWithoutDirName;
    $outfile = "$outdir/$outfile";
    $outfile =~ s/\.gz$//;
    $outfile =~ s/\.fastq$//;
    $outfile =~ s/\.fq$//;
    my $shellScript = "$outfile.bwa.sh";
    $outfile .= ".bwa.bam";
    my $logfile1 = $outfile; $logfile1 =~ s/.bam/.log.txt/;
    ## check whether outfile exists
    if ($outfile eq $file) {
        die "\n\nterminating - cannot figure out a reasonable output file name\n\n";
    }
    if (-e $outfile) {
        print "\nskipping file $file - outfile $outfile already exists\n\n";
        next;
    }
    ### construct the command:
    open (SH, "> $shellScript");
    print SH "#!/bin/bash\n";
    print SH "source /app/lmod/lmod/init/profile\n";
    print SH "module load SAMtools/1.11-GCC-10.2.0\n";
    print SH "module load BWA/0.7.17-GCC-10.2.0\n";
    
    ## get date so I can set up a unique tmp dir name
    my $date = `date -Ins`; chomp $date;
    $date =~ s/,/_/g; $date =~ s/:/_/g; 
    my $tmpDir = "\$\{DELETE30\}/malik_h/$fileNameWithoutDirName" . "_$date";

    ## get basic bwa mem command
    my $bwaSamtoolsCommand;
    if ($paired == 1) {
        if ( $file !~ m/R1|1_sequence|bam_1|_1\.fastq\.gz/) {
            print "\nskipping file $file, as you specified paired-end reads, and this does not look like a file of read1s\n\n"; next;
        }
        ## if paired end, figure out other file with other ends in it
        my $otherEndFile = $file; 
        if ($otherEndFile =~ m/_R1/) {  $otherEndFile =~ s/_R1/_R2/; }
        if ($otherEndFile =~ m/^s_\d_1$/) { $otherEndFile =~ s/1$/2/; }
        if ($otherEndFile =~ m/bam_1/) { $otherEndFile =~ s/bam_1/bam_2/; }
        if ($otherEndFile =~ m/[ES]RR.+?_1/) {
            $otherEndFile =~ s/_1\.fastq\.gz/_2.fastq.gz/;
            $otherEndFile =~ s/_1$/_2/;
            $otherEndFile =~ s/_1\.noDot$/_2.noDot/;
        }
        if ($otherEndFile eq $file) {
            die "\n\nterminating - you specified paired end reads, but I cannot work out the name of the file with the second ends:\n   $otherEndFile\n\n";        
        }
        if (! -e $otherEndFile) {
            die "\n\nterminating - you specified paired end reads, but I cannot locate the file with the second ends:\n    $otherEndFile\n\n";
        }
        ## -v 2 is for verbosity - gives errors and warnings, but not other stuff
        #$command .= " ; (bwa mem -v 2 $genome $file $otherEndFile";
        $bwaSamtoolsCommand = "bwa mem -t $numThreads -v 2 -Y $genome $file $otherEndFile";
    } else {
        #$command .= " ; (bwa mem -v 2 $genome $file";    
        $bwaSamtoolsCommand = "bwa mem -t $numThreads -v 2 -Y $genome $file";    
    }
    
    ## add on to the command to pipe to samtools sort and output as bam:
    $bwaSamtoolsCommand .= " | samtools view -@ $numThreads -Sb - "; ## convert sam to bam
    $bwaSamtoolsCommand .= " | samtools sort -@ $numThreads -O bam -T $tmpDir > $outfile "; ## sort bam
    $bwaSamtoolsCommand = "($bwaSamtoolsCommand) 2>> $logfile1";
    print SH "$bwaSamtoolsCommand\n";
    if ($index == 1) { 
        print SH "samtools index $outfile\n";
        if ($runFlagstat == 1) {
            print SH "samtools flagstat $outfile > $outfile.flagstats\n";
        }
    }
    close SH;
    
    my $runCommand = "bash $shellScript";
    if ($use_sbatch == 1) {
        $runCommand = "sbatch --job-name=bwaMem -t $walltime --cpus-per-task=$numThreads --wrap=\"$runCommand\"";
    } 
    print "command:\n    $runCommand\n\n";
    if ($debug == 0) {system($runCommand);}
}

if ($use_sbatch == 1) {
    print "\n\nSet all jobs going - use sq command to monitor whether there are still any bwaMem commands running\n\n";
}



